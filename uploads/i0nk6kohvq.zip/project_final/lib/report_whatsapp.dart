import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class ReportWhatsAppPage extends StatefulWidget {
  final String sessionKey;

  const ReportWhatsAppPage({super.key, required this.sessionKey});

  @override
  State<ReportWhatsAppPage> createState() => _ReportWhatsAppPageState();
}

class _ReportWhatsAppPageState extends State<ReportWhatsAppPage>
    with TickerProviderStateMixin {
  final targetController = TextEditingController();
  final String baseUrl = "http://nodeyanzzoffc-private.rxpedia.my.id:25597";

  bool isSending = false;
  String selectedReason = "Spam";
  bool blockAfterReport = true;
  int reportCount = 1;

  late AnimationController _glowController;
  late AnimationController _pulseController;

  final List<String> reasons = [
    "Spam",
    "Penipuan / Scam",
    "Konten Berbahaya",
    "Pelecehan",
    "Informasi Palsu",
    "Konten Dewasa",
    "Other",
  ];

  @override
  void initState() {
    super.initState();
    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..repeat(reverse: true);
  }

  String? _formatNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d]'), '');
    if (cleaned.startsWith('0')) return null;
    if (cleaned.length < 8) return null;
    return cleaned;
  }

  Future<void> _sendReport() async {
    final rawInput = targetController.text.trim();
    final target = _formatNumber(rawInput);

    if (target == null) {
      _showAlert("⚠️ Error",
          "Masukkan nomor internasional yang valid (misal: 62xxxxxxxxx), bukan 08xxx.");
      return;
    }

    setState(() => isSending = true);

    int successCount = 0;
    for (int i = 0; i < reportCount; i++) {
      try {
        final res = await http.post(
          Uri.parse("$baseUrl/reportWhatsapp"),
          body: {
            "key": widget.sessionKey,
            "target": target,
            "reason": selectedReason,
            "block": blockAfterReport.toString(),
          },
        );
        final data = jsonDecode(res.body);
        if (data["success"] == true || data["sended"] == true) {
          successCount++;
        }
      } catch (_) {}
      await Future.delayed(const Duration(milliseconds: 400));
    }

    setState(() => isSending = false);

    if (successCount > 0) {
      _showAlert("✅ Berhasil",
          "$successCount/$reportCount report berhasil dikirim ke +$target.");
    } else {
      _showAlert("❌ Gagal", "Gagal mengirim report. Coba lagi nanti.");
    }
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF0D0D0D),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(title,
            style: const TextStyle(
                color: Colors.purpleAccent, fontFamily: 'Orbitron')),
        content: Text(msg,
            style: const TextStyle(
                color: Colors.white70, fontFamily: 'ShareTechMono')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child:
                const Text("OK", style: TextStyle(color: Colors.purpleAccent)),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.purpleAccent),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          "Report WhatsApp",
          style: TextStyle(
            color: Colors.purpleAccent,
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            // === ICON HEADER ===
            AnimatedBuilder(
              animation: _glowController,
              builder: (_, __) => Container(
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.purple.withOpacity(0.1),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.purpleAccent.withOpacity(
                          0.3 + _glowController.value * 0.3),
                      blurRadius: 30,
                      spreadRadius: 5,
                    )
                  ],
                  border: Border.all(
                    color: Colors.purpleAccent
                        .withOpacity(0.5 + _glowController.value * 0.5),
                    width: 1.5,
                  ),
                ),
                child: const Icon(
                  Icons.chat_bubble_rounded,
                  color: Colors.purpleAccent,
                  size: 56,
                ),
              ),
            ),

            const SizedBox(height: 20),

            const Text(
              "WHATSAPP REPORTER",
              style: TextStyle(
                color: Colors.purpleAccent,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold,
                fontSize: 18,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 6),
            const Text(
              "Kirim report ke nomor WhatsApp target",
              style: TextStyle(
                  color: Colors.white54,
                  fontFamily: 'ShareTechMono',
                  fontSize: 13),
            ),

            const SizedBox(height: 30),

            // === FORM ===
            _buildCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _label("📱 Nomor Target"),
                  const SizedBox(height: 8),
                  TextField(
                    controller: targetController,
                    keyboardType: TextInputType.phone,
                    style: const TextStyle(color: Colors.white),
                    cursorColor: Colors.purpleAccent,
                    decoration: InputDecoration(
                      hintText: "62xxxxxxxxx (tanpa +)",
                      hintStyle:
                          const TextStyle(color: Colors.purple),
                      prefixIcon: const Icon(Icons.phone_android,
                          color: Colors.purpleAccent),
                      filled: true,
                      fillColor: Colors.black45,
                      enabledBorder: OutlineInputBorder(
                        borderSide:
                            const BorderSide(color: Colors.purpleAccent),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderSide: const BorderSide(
                            color: Colors.white, width: 1.5),
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),

                  _label("📋 Alasan Report"),
                  const SizedBox(height: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    decoration: BoxDecoration(
                      color: Colors.black45,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: Colors.purpleAccent, width: 1),
                    ),
                    child: DropdownButtonHideUnderline(
                      child: DropdownButton<String>(
                        dropdownColor: const Color(0xFF0D0D0D),
                        value: selectedReason,
                        isExpanded: true,
                        iconEnabledColor: Colors.purpleAccent,
                        style: const TextStyle(color: Colors.white),
                        items: reasons
                            .map((r) => DropdownMenuItem(
                                value: r,
                                child: Text(r,
                                    style: const TextStyle(
                                        color: Colors.purpleAccent,
                                        fontFamily: 'ShareTechMono'))))
                            .toList(),
                        onChanged: (v) => setState(() => selectedReason = v!),
                      ),
                    ),
                  ),

                  const SizedBox(height: 20),

                  _label("🔢 Jumlah Report: $reportCount"),
                  Slider(
                    value: reportCount.toDouble(),
                    min: 1,
                    max: 20,
                    divisions: 19,
                    activeColor: Colors.purpleAccent,
                    inactiveColor: Colors.purple.withOpacity(0.2),
                    label: "$reportCount",
                    onChanged: (v) => setState(() => reportCount = v.toInt()),
                  ),

                  const SizedBox(height: 10),

                  // === BLOCK TOGGLE ===
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 10),
                    decoration: BoxDecoration(
                      color: Colors.purple.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                          color: Colors.purpleAccent.withOpacity(0.3)),
                    ),
                    child: Row(
                      children: [
                        const Icon(Icons.block,
                            color: Colors.purpleAccent, size: 20),
                        const SizedBox(width: 10),
                        const Expanded(
                          child: Text(
                            "Block setelah report",
                            style: TextStyle(
                                color: Colors.white70,
                                fontFamily: 'ShareTechMono',
                                fontSize: 14),
                          ),
                        ),
                        Switch(
                          value: blockAfterReport,
                          onChanged: (v) =>
                              setState(() => blockAfterReport = v),
                          activeColor: Colors.purpleAccent,
                          inactiveTrackColor: Colors.grey.withOpacity(0.3),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // === SEND BUTTON ===
            SizedBox(
              width: double.infinity,
              height: 54,
              child: ElevatedButton.icon(
                onPressed: isSending ? null : _sendReport,
                icon: isSending
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                            color: Colors.white, strokeWidth: 2))
                    : const Icon(Icons.send_rounded, color: Colors.white),
                label: Text(
                  isSending ? "SENDING..." : "KIRIM REPORT",
                  style: const TextStyle(
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.bold,
                    fontSize: 15,
                    letterSpacing: 1.5,
                    color: Colors.white,
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.purple,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16)),
                  elevation: 8,
                  shadowColor: Colors.purpleAccent,
                ),
              ),
            ),

            const SizedBox(height: 20),

            // === INFO ===
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.purple.withOpacity(0.08),
                borderRadius: BorderRadius.circular(14),
                border:
                    Border.all(color: Colors.purpleAccent.withOpacity(0.3)),
              ),
              child: const Row(
                children: [
                  Icon(Icons.info_outline,
                      color: Colors.purpleAccent, size: 18),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      "Nomor harus format internasional tanpa +. Contoh: 6281234567890",
                      style: TextStyle(
                          color: Colors.white54,
                          fontSize: 12,
                          fontFamily: 'ShareTechMono'),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCard({required Widget child}) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.04),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.purpleAccent.withOpacity(0.5)),
        boxShadow: [
          BoxShadow(
            color: Colors.deepPurpleAccent.withOpacity(0.15),
            blurRadius: 20,
            spreadRadius: -5,
          )
        ],
      ),
      child: child,
    );
  }

  Widget _label(String text) {
    return Text(
      text,
      style: const TextStyle(
        color: Colors.purpleAccent,
        fontFamily: 'Orbitron',
        fontWeight: FontWeight.bold,
        fontSize: 13,
      ),
    );
  }

  @override
  void dispose() {
    _glowController.dispose();
    _pulseController.dispose();
    targetController.dispose();
    super.dispose();
  }
}
