import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  final String baseUrl = "http://node4084.nodeecooo.cloudwar.my.id:9131";
  late AnimationController _controller;
  String selectedBugId = "";

  // Warna ungu muda
  final Color primaryPurple = const Color(0xFFB39DDB);
  final Color darkPurple = const Color(0xFF7E57C2);
  final Color lightPurple = const Color(0xFFD1C4E9);
  final Color backgroundColor = const Color(0xFF1A1A2E);
  final Color cardColor = const Color(0xFF16213E);

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    if (widget.listBug.isNotEmpty) {
      selectedBugId = widget.listBug[0]['bug_id'];
    }
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d]'), '');
    if (cleaned.startsWith('0') || cleaned.length < 8) return null;
    return cleaned;
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final target = formatPhoneNumber(rawInput);
    final key = widget.sessionKey;

    if (target == null || key.isEmpty) {
      _showAlert("❌ Invalid Number", "Gunakan nomor internasional (misal: +62, 1, 44), bukan 08xxx.");
      return;
    }

    try {
      final res = await http.get(Uri.parse("$baseUrl/sendBug?key=$key&target=$target&bug=$selectedBugId"));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        _showAlert("⏳ Cooldown", "Tunggu beberapa saat sebelum mengirim lagi.");
      } else if (data["valid"] == false) {
        _showAlert("❌ Key Invalid", "Session key tidak valid. Silakan login ulang.");
      } else if (data["sended"] == false) {
        _showAlert("⚠️ Gagal", "Gagal mengirim bug. Mungkin server sedang maintenance.");
      } else {
        _showAlert("✅ Berhasil", "Bug berhasil dikirim ke $target.");
      }
    } catch (_) {
      _showAlert("❌ Error", "Terjadi kesalahan. Coba lagi.");
    }
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: cardColor,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: primaryPurple.withOpacity(0.5)),
        ),
        title: Text(
          title,
          style: TextStyle(
            color: primaryPurple,
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.bold,
          ),
        ),
        content: Text(
          msg,
          style: const TextStyle(
            color: Colors.white70,
            fontFamily: 'ShareTechMono',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              "OK",
              style: TextStyle(color: primaryPurple),
            ),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [backgroundColor, cardColor],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              // === HEADER CARD ===
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: cardColor.withOpacity(0.8),
                  border: Border.all(color: primaryPurple, width: 1.2),
                  boxShadow: [
                    BoxShadow(
                      color: primaryPurple.withOpacity(0.3),
                      blurRadius: 15,
                      spreadRadius: -3,
                    )
                  ],
                ),
                child: Column(
                  children: [
                    FadeTransition(
                      opacity: Tween(begin: 0.5, end: 1.0).animate(_controller),
                      child: Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: primaryPurple, width: 2),
                        ),
                        child: ClipOval(
                          child: Image.asset(
                            'assets/images/logo.jpg',
                            width: 100,
                            height: 100,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      widget.username,
                      style: TextStyle(
                        color: primaryPurple,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.bold,
                        fontSize: 20,
                        letterSpacing: 1.2,
                      ),
                    ),
                    Text(
                      "Role: ${widget.role.toUpperCase()} • Exp: ${widget.expiredDate}",
                      style: const TextStyle(
                        color: Colors.white70,
                        fontFamily: 'ShareTechMono',
                        fontSize: 13,
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 30),

              // === FORM CONTAINER ===
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: cardColor.withOpacity(0.6),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: primaryPurple.withOpacity(0.6)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Target Number",
                      style: TextStyle(
                        color: primaryPurple,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: targetController,
                      style: const TextStyle(color: Colors.white),
                      cursorColor: primaryPurple,
                      decoration: InputDecoration(
                        hintText: "e.g. +62xxxxxxxxx",
                        hintStyle: TextStyle(color: Colors.white54),
                        filled: true,
                        fillColor: backgroundColor.withOpacity(0.6),
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: primaryPurple.withOpacity(0.5)),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: primaryPurple, width: 2),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        prefixIcon: Icon(Icons.phone, color: primaryPurple),
                      ),
                    ),

                    const SizedBox(height: 25),

                    Text(
                      "Select Bug",
                      style: TextStyle(
                        color: primaryPurple,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      decoration: BoxDecoration(
                        color: backgroundColor.withOpacity(0.6),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: primaryPurple.withOpacity(0.5), width: 1.2),
                      ),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                          dropdownColor: cardColor,
                          value: selectedBugId,
                          isExpanded: true,
                          iconEnabledColor: primaryPurple,
                          style: const TextStyle(color: Colors.white),
                          items: widget.listBug.map((bug) {
                            return DropdownMenuItem<String>(
                              value: bug['bug_id'],
                              child: Text(
                                bug['bug_name'],
                                style: const TextStyle(color: Colors.white),
                              ),
                            );
                          }).toList(),
                          onChanged: (value) {
                            setState(() {
                              selectedBugId = value!;
                            });
                          },
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 35),

              // === SEND BUTTON ===
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _sendBug,
                  icon: Icon(Icons.bug_report, color: Colors.black),
                  label: Text(
                    "SEND BUG",
                    style: TextStyle(
                      fontSize: 18,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.bold,
                      letterSpacing: 1.4,
                      color: Colors.black,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    backgroundColor: primaryPurple,
                    shadowColor: primaryPurple.withOpacity(0.5),
                    elevation: 6,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(18),
                    ),
                  ).copyWith(
                    backgroundColor: WidgetStateProperty.resolveWith<Color>(
                          (states) {
                        if (states.contains(WidgetState.pressed)) {
                          return darkPurple;
                        }
                        return primaryPurple;
                      },
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    targetController.dispose();
    super.dispose();
  }
}
