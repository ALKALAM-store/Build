package com.example.undefined_crasher;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}