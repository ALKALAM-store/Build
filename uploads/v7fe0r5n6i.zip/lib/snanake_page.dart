import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';

class SnakePage extends StatefulWidget {
  const SnakePage({super.key});

  @override
  State<SnakePage> createState() => _SnakePageState();
}

class _SnakePageState extends State<SnakePage> {
  static const int rowSize = 20;
  static const int totalSquares = rowSize * rowSize;

  List<int> snake = [45, 65, 85];
  int food = 100;
  String direction = "down";
  Timer? timer;
  int score = 0;

  void startGame() {
    timer = Timer.periodic(const Duration(milliseconds: 200), (timer) {
      moveSnake();
    });
  }

  void moveSnake() {
    setState(() {
      int newHead;
      switch (direction) {
        case "down":
          newHead = snake.last + rowSize;
          break;
        case "up":
          newHead = snake.last - rowSize;
          break;
        case "left":
          newHead = snake.last - 1;
          break;
        default:
          newHead = snake.last + 1;
      }

      if (newHead >= totalSquares ||
          snake.contains(newHead)) {
        timer?.cancel();
        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text("Game Over"),
            content: Text("Score: $score"),
            actions: [
              TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                    resetGame();
                  },
                  child: const Text("Restart"))
            ],
          ),
        );
        return;
      }

      snake.add(newHead);

      if (newHead == food) {
        score++;
        food = Random().nextInt(totalSquares);
      } else {
        snake.removeAt(0);
      }
    });
  }

  void resetGame() {
    setState(() {
      snake = [45, 65, 85];
      direction = "down";
      score = 0;
      food = Random().nextInt(totalSquares);
    });
    startGame();
  }

  @override
  void initState() {
    super.initState();
    startGame();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Snake - Score: $score")),
      body: GestureDetector(
        onVerticalDragUpdate: (details) {
          if (details.delta.dy > 0 && direction != "up") {
            direction = "down";
          } else if (details.delta.dy < 0 && direction != "down") {
            direction = "up";
          }
        },
        onHorizontalDragUpdate: (details) {
          if (details.delta.dx > 0 && direction != "left") {
            direction = "right";
          } else if (details.delta.dx < 0 && direction != "right") {
            direction = "left";
          }
        },
        child: GridView.builder(
          itemCount: totalSquares,
          gridDelegate:
              const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: rowSize,
          ),
          itemBuilder: (context, index) {
            if (snake.contains(index)) {
              return Container(color: Colors.green);
            } else if (index == food) {
              return Container(color: Colors.red);
            } else {
              return Container(
                margin: const EdgeInsets.all(1),
                color: Colors.black,
              );
            }
          },
        ),
      ),
    );
  }
}