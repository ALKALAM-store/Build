import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class MusicSearchPage extends StatefulWidget {
  const MusicSearchPage({super.key});

  @override
  State<MusicSearchPage> createState() => _MusicSearchPageState();
}

class _MusicSearchPageState extends State<MusicSearchPage> {
  final TextEditingController _controller = TextEditingController();
  final AudioPlayer _player = AudioPlayer();
  List<dynamic> _results = [];
  bool _isLoading = false;

  Future<void> searchMusic(String query) async {
    if (query.isEmpty) return;
    setState(() => _isLoading = true);

    final url = Uri.parse(
        "https://aliicia.my.id/api/music?alicia=${Uri.encodeComponent(query)}");
    final response = await http.get(url);

    setState(() => _isLoading = false);

    if (response.statusCode == 200) {
      try {
        final data = json.decode(response.body);
        // Menyesuaikan struktur JSON (bisa array langsung atau di dalam key)
        setState(() {
          if (data is List) {
            _results = data;
          } else if (data is Map && data.containsKey('results')) {
            _results = data['results'];
          } else if (data is Map && data.containsKey('data')) {
            _results = data['data'];
          } else {
            _results = [];
          }
        });
      } catch (e) {
        setState(() => _results = []);
      }
    } else {
      setState(() => _results = []);
    }
  }

  Future<void> playMusic(String url) async {
    if (url.isEmpty) return;
    await _player.play(UrlSource(url));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      appBar: AppBar(
        title: const Text("Music Search"),
        backgroundColor: const Color(0xFF8B0000),
        foregroundColor: const Color(0xFFE0E0E0),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: _controller,
              style: const TextStyle(color: Color(0xFFE0E0E0)),
              decoration: InputDecoration(
                hintText: "Cari musik...",
                hintStyle: const TextStyle(color: Colors.grey),
                filled: true,
                fillColor: const Color(0xFF1A1A1A),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              onSubmitted: searchMusic,
            ),
            const SizedBox(height: 16),
            Expanded(
              child: _isLoading
                  ? const Center(child: CircularProgressIndicator())
                  : _results.isEmpty
                      ? const Center(
                          child: Text(
                            "Tidak ada hasil ditemukan.",
                            style: TextStyle(color: Colors.grey),
                          ),
                        )
                      : ListView.builder(
                          itemCount: _results.length,
                          itemBuilder: (context, index) {
                            final item = _results[index];
                            final title = item['title'] ?? 'Unknown';
                            final url = item['url'] ?? '';

                            return Card(
                              color: const Color(0xFF1A1A1A),
                              child: ListTile(
                                title: Text(
                                  title,
                                  style: const TextStyle(
                                      color: Color(0xFFE0E0E0)),
                                ),
                                trailing: ElevatedButton(
                                  onPressed: () => playMusic(url),
                                  child: const Text("Play"),
                                ),
                              ),
                            );
                          },
                        ),
            ),
          ],
        ),
      ),
    );
  }
}