import 'dart:collection';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'telegram.dart';
import 'anime_home.dart';
import 'ai_page.dart';
import 'ip_scanner.dart';
import 'port_scanner.dart';
import 'games.dart';

class ToolsPage extends StatelessWidget {
  final String username;
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.username,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
  });

  static const Color bgBlack = Color(0xFF0D0D0F);
  static const Color surfaceDark = Color(0xFF1A0A0A);
  static const Color surfaceGrey = Color(0xFF3D0A0A);
  static const Color textWhite = Colors.white;
  static const Color textGrey = Color(0xFF800000);

  static const Color accentDdos = Color(0xFFB22222); // biru elektrik
  static const Color accentNetwork = Color(0xFFFFD700); // teal
  static const Color accentOsint = Color(0xFFFF0000); // Brigt Red
  static const Color accentDownload = Color(0xFFFF6666); // Light Red
  static const Color accentUtility = Color(0xFFFF7F50); // Coral
  static const Color accentStreaming = Color(0xFF8B0000); // cyan
  static const Color accentAi = Color(0xFF2A1A1A); // lime
  static const Color AccentGames = Color(0xFFFF2400); // Scarlet

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      body: SafeArea(
        child: Column(
          children: [
            // Header Panel
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    accentDdos.withOpacity(0.15),
                    accentNetwork.withOpacity(0.15),
                    accentStreaming.withOpacity(0.15),
                  ],
                ),
                borderRadius: const BorderRadius.only(
                  bottomLeft: Radius.circular(30),
                  bottomRight: Radius.circular(30),
                ),
                border: Border(
                  bottom: BorderSide(color: accentDdos.withOpacity(0.3)),
                ),
              ),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.build_circle_outlined, color: accentAi, size: 28),
                      const SizedBox(width: 12),
                      Text(
                        "SECOND FEATURE",
                        style: TextStyle(
                          color: textWhite,
                          fontSize: 20,
                          fontFamily: 'Orbitron',
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.5,
                          shadows: [
                            Shadow(
                              color: accentDdos.withOpacity(0.8),
                              blurRadius: 10,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    "TrashGlitch - Apps game features and tools",
                    style: TextStyle(
                      color: textGrey,
                      fontSize: 14,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ),

            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: GridView.count(
                  crossAxisCount: 2,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                  childAspectRatio: 1.2,
                  children: [
                    _buildToolCard(
                      icon: Icons.flash_on,
                      title: "Ddos Attack ⚡",
                      subtitle: "Attack & Server",
                      accent: accentDdos,
                      onTap: () => _showDDoSTools(context),
                    ),
                    _buildToolCard(
                      icon: Icons.wifi,
                      title: "Network Attack ⚡",
                      subtitle: "Killer Wifi",
                      accent: accentNetwork,
                      onTap: () => _showNetworkTools(context),
                    ),
                    _buildToolCard(
                      icon: Icons.search,
                      title: "OSINT",
                      subtitle: "Investigation",
                      accent: accentOsint,
                      onTap: () => _showOSINTTools(context),
                    ),
                    _buildToolCard(
                      icon: Icons.download,
                      title: "Downloader",
                      subtitle: "Social Media",
                      accent: accentDownload,
                      onTap: () => _showDownloaderTools(context),
                    ),
                    _buildToolCard(
                      icon: Icons.build,
                      title: "Utilities",
                      subtitle: "Extra Tools",
                      accent: accentUtility,
                      onTap: () => _showUtilityTools(context),
                    ),
                    _buildToolCard(
                      icon: Icons.play_circle_fill,
                      title: "Streaming",
                      subtitle: "Nonton & Hiburan",
                      accent: accentStreaming,
                      onTap: () => _showStreamingTools(context),
                    ),
                    _buildToolCard(
                      icon: Icons.sports_esports,
                      title: "Games",
                      subtitle: "Bermain Gamee",
                      accent: AccentGames,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => GamesPage(),
                          ),
                        );
                      },
                    ),
                    _buildToolCard(
                      icon: Icons.smart_toy,
                      title: "AI Assistant",
                      subtitle: "Tanya AI Pintar",
                      accent: accentAi,
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const AiPage(),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildToolCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color accent,
    required VoidCallback onTap,
  }) {
    return TweenAnimationBuilder(
      tween: Tween<double>(begin: 0, end: 1),
      duration: const Duration(milliseconds: 600),
      curve: Curves.easeOutBack,
      builder: (context, double scale, child) {
        return Transform.scale(scale: scale, child: child);
      },
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          decoration: BoxDecoration(
            color: surfaceDark,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: accent.withOpacity(0.4), width: 1.5),
            boxShadow: [
              BoxShadow(
                color: accent.withOpacity(0.1),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: accent.withOpacity(0.15),
                    shape: BoxShape.circle,
                    border: Border.all(color: accent.withOpacity(0.5)),
                  ),
                  child: Icon(icon, color: accent, size: 24),
                ),
                const SizedBox(height: 12),
                Text(
                  title,
                  style: TextStyle(
                    color: accent,
                    fontSize: 13,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: TextStyle(
                    color: textGrey,
                    fontSize: 12,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showDDoSTools(BuildContext context) {
    _showBottomSheet(
      context: context,
      title: "Ddos Attack ⚡",
      icon: Icons.flash_on,
      accent: accentDdos,
      options: [
        _ToolOption(icon: Icons.flash_on, label: "Attack Server ⚡", accent: accentDdos, onTap: () {
          Navigator.push(context, MaterialPageRoute(builder: (_) => AttackPanel(sessionKey: sessionKey, listDoos: listDoos)));
        }),
        _ToolOption(icon: Icons.dns, label: "Manage Server ⚡", accent: accentDdos, onTap: () {
          Navigator.push(context, MaterialPageRoute(builder: (_) => ManageServerPage(keyToken: sessionKey)));
        }),
      ],
    );
  }

  void _showNetworkTools(BuildContext context) {
    _showBottomSheet(
      context: context,
      title: "Network Tools 📡",
      icon: Icons.wifi,
      accent: accentNetwork,
      options: [
        _ToolOption(icon: Icons.telegram, label: "Telegram Spam 🩸", accent: accentNetwork, onTap: () {
          Navigator.push(context, MaterialPageRoute(builder: (_) => TelegramSpamPage(sessionKey: sessionKey)));
        }),
        _ToolOption(icon: Icons.newspaper_outlined, label: "Spam NGL 🧬", accent: accentNetwork, onTap: () {
          Navigator.push(context, MaterialPageRoute(builder: (_) => NglPage()));
        }),
        _ToolOption(icon: Icons.wifi_off, label: "WiFi Killer (Internal) 📡", accent: accentNetwork, onTap: () {
          Navigator.push(context, MaterialPageRoute(builder: (_) => WifiKillerPage()));
        }),
        _ToolOption(icon: Icons.router, label: "WiFi Killer (External) 📡", accent: accentNetwork, onTap: () {
          Navigator.push(context, MaterialPageRoute(builder: (_) => WifiInternalPage(sessionKey: sessionKey)));
        }),
      ],
    );
  }

  void _showOSINTTools(BuildContext context) {
    _showBottomSheet(
      context: context,
      title: "OSINT TOOLS 🔎",
      icon: Icons.search,
      accent: accentOsint,
      options: [
        _ToolOption(icon: Icons.badge, label: "NIK Detail 👤", accent: accentOsint, onTap: () {
          Navigator.push(context, MaterialPageRoute(builder: (_) => const NikCheckerPage()));
        }),
        _ToolOption(icon: Icons.domain, label: "Domain OSINT 🌐", accent: accentOsint, onTap: () {
          Navigator.push(context, MaterialPageRoute(builder: (_) => const DomainOsintPage()));
        }),
      ],
    );
  }

  void _showDownloaderTools(BuildContext context) {
    _showBottomSheet(
      context: context,
      title: "Media Downloader",
      icon: Icons.download,
      accent: accentDownload,
      options: [
        _ToolOption(icon: Icons.video_library, label: "TikTok Downloader", accent: accentDownload, onTap: () {
          Navigator.push(context, MaterialPageRoute(builder: (_) => const TiktokDownloaderPage()));
        }),
        _ToolOption(icon: Icons.camera_alt, label: "Instagram Downloader", accent: accentDownload, onTap: () {
          Navigator.push(context, MaterialPageRoute(builder: (_) => const InstagramDownloaderPage()));
        }),
      ],
    );
  }

  void _showUtilityTools(BuildContext context) {
    _showBottomSheet(
      context: context,
      title: "Utility Tools",
      icon: Icons.build,
      accent: accentUtility,
      options: [
        _ToolOption(icon: Icons.qr_code, label: "QR Generator", accent: accentUtility, onTap: () {
          Navigator.push(context, MaterialPageRoute(builder: (_) => const QrGeneratorPage()));
        }),
        _ToolOption(icon: Icons.security, label: "IP Scanner", accent: accentUtility, onTap: () {
          Navigator.push(context, MaterialPageRoute(builder: (_) => const IpScannerPage()));
        }),
        _ToolOption(icon: Icons.network_check, label: "Port Scanner", accent: accentUtility, onTap: () {
          Navigator.push(context, MaterialPageRoute(builder: (_) => const PortScannerPage()));
        }),
      ],
    );
  }

  void _showStreamingTools(BuildContext context) {
    _showBottomSheet(
      context: context,
      title: "Streaming & Hiburan",
      icon: Icons.play_circle_fill,
      accent: accentStreaming,
      options: [
        _ToolOption(icon: Icons.movie_filter, label: "Anime Stream", accent: accentStreaming, onTap: () {
          Navigator.push(context, MaterialPageRoute(builder: (_) => const HomeAnimePage()));
        }),
      ],
    );
  }

  void _showBottomSheet({
    required BuildContext context,
    required String title,
    required IconData icon,
    required Color accent,
    required List<_ToolOption> options,
  }) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => Container(
        constraints: BoxConstraints(
          maxHeight: MediaQuery.of(context).size.height * 0.7,
        ),
        decoration: BoxDecoration(
          color: surfaceDark,
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(30),
            topRight: Radius.circular(30),
          ),
          border: Border.all(color: accent.withOpacity(0.3)),
          boxShadow: [
            BoxShadow(
              color: accent.withOpacity(0.1),
              blurRadius: 20,
              spreadRadius: 5,
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [accent.withOpacity(0.2), Colors.transparent],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(30),
                  topRight: Radius.circular(30),
                ),
                border: Border(bottom: BorderSide(color: accent.withOpacity(0.3))),
              ),
              child: Row(
                children: [
                  Icon(icon, color: accent, size: 24),
                  const SizedBox(width: 12),
                  Text(
                    title,
                    style: TextStyle(
                      color: accent,
                      fontSize: 20,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
            Flexible(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: ListView(
                  shrinkWrap: true,
                  children: options.map((opt) => _buildToolOption(
                    icon: opt.icon,
                    label: opt.label,
                    accent: opt.accent,
                    onTap: () {
                      Navigator.pop(context);
                      opt.onTap();
                    },
                  )).toList(),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildToolOption({
    required IconData icon,
    required String label,
    required Color accent,
    required VoidCallback onTap,
  }) {
    return Card(
      color: surfaceGrey,
      margin: const EdgeInsets.symmetric(vertical: 6),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15),
        side: BorderSide(color: accent.withOpacity(0.4)),
      ),
      elevation: 4,
      shadowColor: accent.withOpacity(0.15),
      child: ListTile(
        leading: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: accent.withOpacity(0.15),
            shape: BoxShape.circle,
            border: Border.all(color: accent.withOpacity(0.5)),
          ),
          child: Icon(icon, color: accent),
        ),
        title: Text(
          label,
          style: TextStyle(
            color: textWhite,
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.w500,
          ),
        ),
        trailing: Icon(Icons.arrow_forward_ios, color: accent, size: 14),
        onTap: onTap,
      ),
    );
  }
}

class _ToolOption {
  final IconData icon;
  final String label;
  final Color accent;
  final VoidCallback onTap;

  _ToolOption({
    required this.icon,
    required this.label,
    required this.accent,
    required this.onTap,
  });
}