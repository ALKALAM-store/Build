import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:math';
import 'package:vibration/vibration.dart';

class GamesPage extends StatelessWidget {
  const GamesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text("TrashGlitch - Apps GAMES", style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.2)),
        centerTitle: true,
        backgroundColor: Colors.grey[900],
        elevation: 0,
      ),
      body: GridView(
        padding: const EdgeInsets.all(12.0),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          childAspectRatio: 0.9,
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
        ),
        children: [
          _buildGameCard(context, "1. GALAXY SHOOTER", Colors.blue, const SpaceShooterGame()),
          _buildGameCard(context, "2. TURBO RACER", Colors.orange, const TurboRacerGame()),
          _buildGameCard(context, "3. DARK HORROR", Colors.red, const HorrorGame()),
          _buildGameCard(context, "4. CHESS MASTER", Colors.brown, const ChessGame()),
          _buildGameCard(context, "5. TUG OF WAR", Colors.green, const TugOfWarGame()),
          _buildGameCard(context, "6. IQ MASTER", Colors.pink, const IQTestGame()),
          _buildGameCard(context, "7. ULAR TANGGA", Colors.purple, const SnakesGame()),
          _buildGameCard(context, "7. PUZZLE QUIS", Colors.purple, const PuzzleGame()),
        ],
      ),
    );
  }

  Widget _buildGameCard(BuildContext ctx, String title, Color color, Widget game) {
    return InkWell(
      onTap: () => Navigator.push(ctx, MaterialPageRoute(builder: (_) => game)),
      borderRadius: BorderRadius.circular(16),
      child: Container(
        decoration: BoxDecoration(
          color: color.withOpacity(0.15),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withOpacity(0.5), width: 1.5),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.2),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Center(
          child: Text(
            title,
            style: TextStyle(
              color: color, 
              fontSize: 18, 
              fontWeight: FontWeight.w800,
              fontFamily: 'Rajdhani',
            ),
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }
}

class Joystick extends StatelessWidget {
  final VoidCallback onUp;
  final VoidCallback onDown;
  final VoidCallback onLeft;
  final VoidCallback onRight;

  const Joystick({
    Key? key,
    required this.onUp,
    required this.onDown,
    required this.onLeft,
    required this.onRight,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 140,
      height: 140,
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.1),
        shape: BoxShape.circle,
        border: Border.all(color: Colors.white.withOpacity(0.2), width: 2),
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          Positioned(top: 5, child: _JoyBtn(icon: Icons.arrow_upward, onTap: onUp)),
          Positioned(bottom: 5, child: _JoyBtn(icon: Icons.arrow_downward, onTap: onDown)),
          Positioned(left: 5, child: _JoyBtn(icon: Icons.arrow_back, onTap: onLeft)),
          Positioned(right: 5, child: _JoyBtn(icon: Icons.arrow_forward, onTap: onRight)),
          const CircleAvatar(radius: 25, backgroundColor: Colors.white24, child: Icon(Icons.gamepad, color: Colors.white70)),
        ],
      ),
    );
  }
}

class _JoyBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _JoyBtn({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 50, height: 50,
        color: Colors.transparent,
        child: Icon(icon, color: Colors.white70, size: 28),
      ),
    );
  }
}

class SpaceShooterGame extends StatefulWidget {
  const SpaceShooterGame({Key? key}) : super(key: key);
  @override
  State<SpaceShooterGame> createState() => _SpaceShooterGameState();
}

class _SpaceShooterGameState extends State<SpaceShooterGame> {
  double playerX = 0.5;
  List<double> enemies = [0.2, 0.5, 0.8];
  List<double> enemyY = [-0.2, -0.6, -1.0];
  List<Map<String, double>> balls = [];
  int score = 0;
  bool gameOver = false;
  Timer? loop;

  @override
  void initState() {
    super.initState();
    loop = Timer.periodic(const Duration(milliseconds: 30), (t) => update());
  }

  void update() {
    if (gameOver) return;
    setState(() {
      for (int i = 0; i < enemyY.length; i++) {
        enemyY[i] += 0.02 + (score * 0.001);
        if (enemyY[i] > 1.2) {
          enemyY[i] = -0.2;
          enemies[i] = Random().nextDouble();
        }
      }

      for (var ball in balls) {
        ball["y"] = (ball["y"] ?? 0) - 0.05;
      }
      balls.removeWhere((b) => (b["y"] ?? 0) < 0);

      for (int i = 0; i < enemies.length; i++) {
        for (var ball in balls) {
          if ((ball["y"]! - enemyY[i]).abs() < 0.1 &&
              (ball["x"]! - enemies[i]).abs() < 0.1) {
            score++;
            enemyY[i] = -0.2;
            enemies[i] = Random().nextDouble();
            balls.remove(ball);
            break;
          }
        }
      }

      for (int i = 0; i < enemyY.length; i++) {
        if ((enemyY[i] - 0.9).abs() < 0.1 && (enemies[i] - playerX).abs() < 0.1) {
          gameOver = true;
          loop?.cancel();
          Vibration.vibrate(duration: 500);
        }
      }
    });
  }

  void move(String dir) {
    setState(() {
      if (dir == 'left' && playerX > 0.1) playerX -= 0.05;
      if (dir == 'right' && playerX < 0.9) playerX += 0.05;
    });
  }

  void shoot() {
    setState(() {
      balls.add({"x": playerX, "y": 0.9});
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          CustomPaint(
            size: Size.infinite,
            painter: SpacePainter(
             playerX: playerX,
             enemies: enemies,
             enemyY: enemyY,
             bullets: balls,
             ),
          ),
          Positioned(
            top: 40,
            left: 20,
            child: Text("SCORE: $score",
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold)),
          ),
          if (gameOver)
            const Center(
                child: Text("GAME OVER",
                    style: TextStyle(
                        color: Colors.red,
                        fontSize: 40,
                        fontWeight: FontWeight.bold))),
          if (!gameOver) ...[
            Positioned(bottom: 30, left: 30, child: Joystick(onUp: () {}, onDown: () {}, onLeft: () => move('left'), onRight: () => move('right'))),
            Positioned(bottom: 50, right: 30, child: GestureDetector(onTap: shoot, child: Container(width: 80, height: 80, decoration: const BoxDecoration(color: Colors.red, shape: BoxShape.circle), child: const Icon(Icons.radio_button_checked, color: Colors.white)))),
          ]
        ],
      ),
    );
  }
}

class SpacePainter extends CustomPainter {
  final double playerX;
  final List<double> enemies;
  final List<double> enemyY;
  final List<Map<String, double>> bullets; // FIXED

  SpacePainter({
    required this.playerX,
    required this.enemies,
    required this.enemyY,
    required this.bullets,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final shipPaint = Paint()..color = Colors.cyan;
    final enemyPaint = Paint()..color = Colors.red;
    final bulletPaint = Paint()..color = Colors.yellow;

    // Draw player
    canvas.drawCircle(
        Offset(size.width * playerX, size.height * 0.9), 20, shipPaint);

    // Draw enemies
    for (int i = 0; i < enemies.length; i++) {
      canvas.drawRect(
        Rect.fromCenter(
          center: Offset(size.width * enemies[i], size.height * enemyY[i]),
          width: 40,
          height: 40,
        ),
        enemyPaint,
      );
    }

    // Draw bullets using x,y from map
    for (var b in bullets) {
      canvas.drawCircle(
        Offset(size.width * b["x"]!, size.height * b["y"]!),
        5,
        bulletPaint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

class PuzzleGame extends StatefulWidget {
  const PuzzleGame({super.key});

  @override
  State<PuzzleGame> createState() => _PuzzleGameState();
}

class _PuzzleGameState extends State<PuzzleGame> {
  List<int> tiles = List.generate(16, (i) => i); // 0 = kosong

  @override
  void initState() {
    super.initState();
    tiles.shuffle(Random());
  }

  void moveTile(int index) {
    int emptyIndex = tiles.indexOf(0);
    if ((index - emptyIndex).abs() == 1 && index ~/ 4 == emptyIndex ~/ 4 ||
        (index - emptyIndex).abs() == 4) {
      setState(() {
        tiles[emptyIndex] = tiles[index];
        tiles[index] = 0;
      });
    }
  }

  bool isSolved() {
    for (int i = 0; i < 15; i++) {
      if (tiles[i] != i + 1) return false;
    }
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(isSolved() ? "🎉 Puzzle Selesai!" : "Nted Crasher Puzzle",
                style: const TextStyle(color: Colors.white, fontSize: 22)),
            const SizedBox(height: 20),
            SizedBox(
              width: 300,
              height: 300,
              child: GridView.builder(
                itemCount: 16,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 4),
                itemBuilder: (context, index) {
                  return GestureDetector(
                    onTap: () => moveTile(index),
                    child: Container(
                      margin: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: tiles[index] == 0
                            ? Colors.grey[900]
                            : Colors.blueAccent,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Center(
                        child: Text(
                          tiles[index] == 0 ? '' : tiles[index].toString(),
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 24,
                              fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class TurboRacerGame extends StatefulWidget {
  const TurboRacerGame({Key? key}) : super(key: key);
  @override
  State<TurboRacerGame> createState() => _TurboRacerGameState();
}

class _TurboRacerGameState extends State<TurboRacerGame> {
  double carX = 0.5;
  double speed = 0.05;
  List<double> trafficX = [0.2, 0.8, 0.5];
  List<double> trafficY = [-0.2, -0.6, -1.0];
  bool crashed = false;
  Timer? loop;

  @override
  void initState() {
    super.initState();
    loop = Timer.periodic(const Duration(milliseconds: 30), (t) => update());
  }

  void update() {
    if (crashed) return;
    setState(() {
      for (int i = 0; i < trafficY.length; i++) {
        trafficY[i] += speed;
        if (trafficY[i] > 1.2) {
          trafficY[i] = -0.2;
          trafficX[i] = (Random().nextInt(3) + 1) / 4;
        }
      }
      for (int i = 0; i < trafficY.length; i++) {
        if ((trafficY[i] - 0.9).abs() < 0.1 && (trafficX[i] - carX).abs() < 0.1) {
          crashed = true;
          loop?.cancel();
          Vibration.vibrate(duration: 500);
        }
      }
    });
  }

  void steer(String dir) {
    if (crashed) return;
    setState(() {
      if (dir == 'left' && carX > 0.25) carX -= 0.25;
      if (dir == 'right' && carX < 0.75) carX += 0.25;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[800],
      body: Stack(
        children: [
          CustomPaint(size: Size.infinite, painter: RoadPainter(carX: carX, trafficX: trafficX, trafficY: trafficY)),
          if (crashed) const Center(child: Text("CRASHED!", style: TextStyle(color: Colors.red, fontSize: 40, fontWeight: FontWeight.bold))),
          if (!crashed) Positioned(bottom: 30, left: 30, child: Joystick(onUp: () {}, onDown: () {}, onLeft: () => steer('left'), onRight: () => steer('right'))),
        ],
      ),
    );
  }
}

class RoadPainter extends CustomPainter {
  final double carX;
  final List<double> trafficX;
  final List<double> trafficY;
  RoadPainter({required this.carX, required this.trafficX, required this.trafficY});

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), Paint()..color = Colors.grey[700]!);
    for (double i = 0; i < size.height; i += 100) {
      canvas.drawLine(Offset(size.width * 0.33, i), Offset(size.width * 0.33, i + 50), Paint()..color = Colors.white..strokeWidth = 5);
      canvas.drawLine(Offset(size.width * 0.66, i), Offset(size.width * 0.66, i + 50), Paint()..color = Colors.white..strokeWidth = 5);
    }
    canvas.drawRect(Rect.fromCenter(center: Offset(size.width * carX, size.height * 0.85), width: 50, height: 80), Paint()..color = Colors.blue);
    for (int i = 0; i < trafficX.length; i++) {
      canvas.drawRect(Rect.fromCenter(center: Offset(size.width * trafficX[i], size.height * trafficY[i]), width: 50, height: 80), Paint()..color = Colors.red);
    }
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

class HorrorGame extends StatefulWidget {
  const HorrorGame({Key? key}) : super(key: key);
  @override
  State<HorrorGame> createState() => _HorrorGameState();
}

class _HorrorGameState extends State<HorrorGame> {
  double playerX = 0.5, playerY = 0.8, battery = 100.0;
  bool monsterVisible = false;
  String status = "Cari Pintu Keluar (Hijau)";
  Random random = Random();

  void move(String dir) {
    setState(() {
      if (dir == 'left' && playerX > 0.1) playerX -= 0.05;
      if (dir == 'right' && playerX < 0.9) playerX += 0.05;
      if (dir == 'up' && playerY > 0.1) playerY -= 0.05;
      if (dir == 'down' && playerY < 0.9) playerY += 0.05;
      battery -= 0.5;
      if (random.nextInt(50) == 0) {
        monsterVisible = true;
        status = "ADA SESUATU!";
        Vibration.vibrate(duration: 200);
        Future.delayed(const Duration(seconds: 2), () {
          if (mounted) {
            setState(() { monsterVisible = false; status = "Aman..."; });
          }
        });
      }
      double dist = sqrt(pow(playerX - 0.5, 2) + pow(playerY - 0.1, 2));
      if (dist < 0.1) {
        showDialog(context: context, builder: (_) => AlertDialog(title: const Text("KELUAR!"), content: const Text("Selamat!"), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text("OK"))]));
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          Positioned.fill(child: CustomPaint(painter: FlashlightPainter(playerX: playerX, playerY: playerY, battery: battery))),
          Positioned(top: 40, left: 20, child: Text("Battery: ${battery.toInt()}%", style: const TextStyle(color: Colors.yellow, fontSize: 20))),
          if (monsterVisible) const Center(child: Text("👹", style: TextStyle(fontSize: 100))),
          if (battery <= 0) const Center(child: Text("BATERE HABIS", style: TextStyle(color: Colors.red, fontSize: 30))),
          if (battery > 0) Positioned(bottom: 30, left: 30, child: Joystick(onUp: () => move('up'), onDown: () => move('down'), onLeft: () => move('left'), onRight: () => move('right'))),
        ],
      ),
    );
  }
}

class FlashlightPainter extends CustomPainter {
  final double playerX, playerY, battery;
  FlashlightPainter({required this.playerX, required this.playerY, required this.battery});

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), Paint()..color = Colors.black);
    if (battery <= 0) return;
    final center = Offset(size.width * playerX, size.height * playerY);
    final gradient = RadialGradient(colors: [Colors.yellow.withOpacity(0.3), Colors.black], stops: [0.0, 1.0]);
    canvas.drawCircle(center, battery * 3, Paint()..shader = gradient.createShader(Rect.fromCircle(center: center, radius: battery * 3)));
    canvas.drawCircle(Offset(size.width * 0.5, size.height * 0.1), 20, Paint()..color = Colors.green);
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}

// =======================================================
// GAME 4: CHESS MASTER
// =======================================================

class ChessGame extends StatefulWidget {
  const ChessGame({Key? key}) : super(key: key);
  @override
  State<ChessGame> createState() => _ChessGameState();
}

class _ChessGameState extends State<ChessGame> {
  late List<List<String>> board;
  String turn = 'white';
  int? selectedRow, selectedCol;
  String status = "Giliran: Putih";

  @override
  void initState() {
    super.initState();
    _resetGame();
  }

  void _resetGame() {
    board = [
      ['r', 'n', 'b', 'q', 'k', 'b', 'n', 'r'],
      ['p', 'p', 'p', 'p', 'p', 'p', 'p', 'p'],
      ['', '', '', '', '', '', '', ''],
      ['', '', '', '', '', '', '', ''],
      ['', '', '', '', '', '', '', ''],
      ['', '', '', '', '', '', '', ''],
      ['P', 'P', 'P', 'P', 'P', 'P', 'P', 'P'],
      ['R', 'N', 'B', 'Q', 'K', 'B', 'N', 'R'],
    ];
    turn = 'white';
    selectedRow = null;
    setState(() {});
  }

  bool _isWhite(String p) => p == p.toUpperCase() && p.isNotEmpty;
  bool _isMyPiece(String p) => (turn == 'white' && _isWhite(p)) || (turn == 'black' && !_isWhite(p) && p.isNotEmpty);

  void _onTap(int r, int c) {
    String p = board[r][c];
    if (_isMyPiece(p)) {
      setState(() { selectedRow = r; selectedCol = c; status = "Pilih: ${p.toUpperCase()}"; });
      Vibration.vibrate(duration: 30);
    } else if (selectedRow != null) {
      if (_isValidMove(selectedRow!, selectedCol!, r, c, board[selectedRow!][selectedCol!])) {
        setState(() {
          board[r][c] = board[selectedRow!][selectedCol!];
          board[selectedRow!][selectedCol!] = '';
          turn = turn == 'white' ? 'black' : 'white';
          status = "Giliran: ${turn == 'white' ? 'Putih' : 'Hitam'}";
          selectedRow = null;
        });
        Vibration.vibrate(duration: 50);
      }
    }
  }

  bool _isValidMove(int r1, int c1, int r2, int c2, String p) {
    if (r1 == r2 && c1 == c2) return false;
    String target = board[r2][c2];
    if (target.isNotEmpty && _isWhite(target) == _isWhite(p)) return false;
    int dr = r2 - r1, dc = c2 - c1;
    p = p.toLowerCase();
    switch (p) {
      case 'p': int dir = _isWhite(board[r1][c1]) ? -1 : 1; if (c1 == c2 && target.isEmpty && dr == dir) return true; if ((c2 - c1).abs() == 1 && dr == dir && target.isNotEmpty) return true; return false;
      case 'r': if (r1 != r2 && c1 != c2) return false; return _isPathClear(r1, c1, r2, c2);
      case 'b': if ((dr - dc).abs() != 0) return false; return _isPathClear(r1, c1, r2, c2);
      case 'q': if (r1 != r2 && c1 != c2 && (dr - dc).abs() != 0) return false; return _isPathClear(r1, c1, r2, c2);
      case 'n': return (dr.abs() == 2 && dc.abs() == 1) || (dr.abs() == 1 && dc.abs() == 2);
      case 'k': return dr.abs() <= 1 && dc.abs() <= 1;
    }
    return false;
  }

  bool _isPathClear(int r1, int c1, int r2, int c2) {
    int dr = (r2 - r1).sign, dc = (c2 - c1).sign;
    int r = r1 + dr, c = c1 + dc;
    while (r != r2 || c != c2) {
      if (board[r][c].isNotEmpty) return false;
      r += dr; c += dc;
    }
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.brown[900],
      appBar: AppBar(title: const Text("Chess 2P"), actions: [IconButton(icon: const Icon(Icons.refresh), onPressed: _resetGame)]),
      body: Column(
        children: [
          Padding(padding: const EdgeInsets.all(8), child: Text(status, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white))),
          Expanded(
            child: GridView.builder(
              itemCount: 64,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 8),
              itemBuilder: (ctx, i) {
                int r = i ~/ 8, c = i % 8;
                bool isWhiteSquare = (r + c) % 2 == 0;
                bool isSelected = selectedRow == r && selectedCol == c;
                return GestureDetector(
                  onTap: () => _onTap(r, c),
                  child: Container(
                    decoration: BoxDecoration(color: isSelected ? Colors.green : (isWhiteSquare ? Colors.white : Colors.grey[800]), border: Border.all(color: Colors.black)),
                    child: Center(child: Text(_getPieceIcon(board[r][c]), style: const TextStyle(fontSize: 32))),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  String _getPieceIcon(String p) {
    const map = {'r': '♜', 'n': '♞', 'b': '♝', 'q': '♛', 'k': '♚', 'p': '♟', 'R': '♜', 'N': '♞', 'B': '♝', 'Q': '♛', 'K': '♚', 'P': '♟'};
    return map[p] ?? '';
  }
}

class TugOfWarGame extends StatefulWidget {
  const TugOfWarGame({Key? key}) : super(key: key);
  @override
  State<TugOfWarGame> createState() => _TugOfWarGameState();
}

class _TugOfWarGameState extends State<TugOfWarGame> {
  double ropePos = 0.0;
  String result = "";
  bool isGameOver = false;

  void pullLeft() {
    if (isGameOver) return;
    setState(() {
      ropePos -= 5; ropePos += 2;
      _checkWin();
    });
    Vibration.vibrate(duration: 30);
  }

  void _checkWin() {
    if (ropePos <= -100) { isGameOver = true; result = "KAMU KALAH!"; } 
    else if (ropePos >= 100) { isGameOver = true; result = "KAMU MENANG!"; }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blueGrey[900],
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Text("MUSUH", style: TextStyle(fontSize: 24, color: Colors.red)),
          const SizedBox(height: 20),
          Stack(alignment: Alignment.center, children: [
            Container(width: 300, height: 20, color: Colors.brown),
            Positioned(left: 150 + ropePos, child: const Icon(Icons.flag, color: Colors.yellow, size: 40))
          ]),
          const SizedBox(height: 20),
          const Text("KAMU", style: TextStyle(fontSize: 24, color: Colors.blue)),
          const SizedBox(height: 50),
          if (!isGameOver) SizedBox(width: 200, height: 80, child: ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: Colors.green), onPressed: pullLeft, child: const Text("TARIK!!!", style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)))),
          if (isGameOver) ...[
            Text(result, style: const TextStyle(fontSize: 32, fontWeight: FontWeight.bold, color: Colors.white)),
            const SizedBox(height: 20),
            ElevatedButton(onPressed: () => setState(() { ropePos = 0; isGameOver = false; result = ""; }), child: const Text("MAIN LAGI"))
          ]
        ],
      ),
    );
  }
}

class IQTestGame extends StatefulWidget {
  const IQTestGame({Key? key}) : super(key: key);
  @override
  State<IQTestGame> createState() => _IQTestGameState();
}

class _IQTestGameState extends State<IQTestGame> {
  final List<Color> buttonColors = [Colors.red, Colors.blue, Colors.green, Colors.yellow];
  List<int> sequence = [];
  List<int> playerInput = [];
  bool isShowingSequence = false;
  int level = 1;
  String msg = "Mulai";

  void startGame() {
    setState(() { sequence = []; playerInput = []; level = 1; msg = "Lihat..."; });
    addStep();
  }

  void addStep() async {
    setState(() { isShowingSequence = true; playerInput = []; msg = "Hafal..."; });
    await Future.delayed(const Duration(milliseconds: 500));
    sequence.add(Random().nextInt(4));
    for (int index in sequence) {
      await Future.delayed(const Duration(milliseconds: 300));
      await Future.delayed(const Duration(milliseconds: 500));
    }
    setState(() { isShowingSequence = false; msg = "Ulangi!"; });
  }

  void onBtnTap(int index) {
    if (isShowingSequence) return;
    playerInput.add(index);
    if (playerInput[playerInput.length - 1] != sequence[playerInput.length - 1]) {
      setState(() { msg = "SALAH! Level: $level"; isShowingSequence = true; });
      Vibration.vibrate(duration: 500);
    } else {
      if (playerInput.length == sequence.length) {
        level++;
        setState(() { msg = "BENAR! Level $level"; });
        Future.delayed(const Duration(seconds: 1), () => addStep());
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(msg, style: const TextStyle(fontSize: 24, color: Colors.white)),
            const SizedBox(height: 30),
            Column(
              children: List.generate(2, (r) => Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(2, (c) => Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: GestureDetector(
                    onTap: () => onBtnTap(r * 2 + c),
                    child: Container(
                      width: 100, height: 100,
                      decoration: BoxDecoration(color: buttonColors[r * 2 + c], borderRadius: BorderRadius.circular(15), border: Border.all(color: Colors.white)),
                    ),
                  ),
                )),
              )),
            ),
            const SizedBox(height: 30),
            ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: Colors.pink), onPressed: startGame, child: const Text("MULAI TEST"))
          ],
        ),
      ),
    );
  }
}

class SnakesGame extends StatefulWidget {
  const SnakesGame({Key? key}) : super(key: key);
  @override
  State<SnakesGame> createState() => _SnakesGameState();
}

class _SnakesGameState extends State<SnakesGame> {
  int pos1 = 1, pos2 = 1;
  int turn = 1;
  bool isRolling = false;
  final Map<int, int> rules = {4: 14, 9: 31, 20: 38, 28: 84, 40: 59, 17: 7, 54: 34, 62: 19, 87: 24, 93: 73, 99: 78};

  void rollDice() {
    if (isRolling) return;
    setState(() { isRolling = true; });
    int dice = Random().nextInt(6) + 1;
    Future.delayed(const Duration(seconds: 1), () {
      setState(() {
        if (turn == 1) {
          pos1 += dice; if (pos1 > 100) pos1 = 100;
          if (rules.containsKey(pos1)) pos1 = rules[pos1]!;
          turn = 2;
        } else {
          pos2 += dice; if (pos2 > 100) pos2 = 100;
          if (rules.containsKey(pos2)) pos2 = rules[pos2]!;
          turn = 1;
        }
        isRolling = false;
        _checkWin();
      });
    });
  }

  void _checkWin() {
    if (pos1 == 100) _showWin("Pemain 1");
    if (pos2 == 100) _showWin("Pemain 2");
  }

  void _showWin(String winner) {
    showDialog(context: context, builder: (_) => AlertDialog(title: Text("$winner Menang!"), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text("OK"))]));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          Expanded(
            child: GridView.builder(
              itemCount: 100,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 10),
              itemBuilder: (ctx, i) {
                int num = 100 - i;
                bool isP1 = pos1 == num;
                bool isP2 = pos2 == num;
                return Container(
                  decoration: BoxDecoration(color: (num % 2 == 0) ? Colors.purple[100] : Colors.purple[50], border: Border.all(color: Colors.black26)),
                  child: Stack(
                    children: [
                      Center(child: Text("$num", style: const TextStyle(fontWeight: FontWeight.bold))),
                      if (isP1) const Positioned(top: 2, left: 2, child: CircleAvatar(radius: 8, backgroundColor: Colors.blue)),
                      if (isP2) const Positioned(bottom: 2, right: 2, child: CircleAvatar(radius: 8, backgroundColor: Colors.red)),
                    ],
                  ),
                );
              },
            ),
          ),
          Container(
            padding: const EdgeInsets.all(20),
            color: Colors.grey[200],
            child: Column(
              children: [
                Text("Giliran: Pemain $turn", style: const TextStyle(fontSize: 20)),
                const SizedBox(height: 10),
                if (isRolling) const CircularProgressIndicator()
                else ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: Colors.purple), onPressed: rollDice, child: const Text("KOCOK DADU", style: TextStyle(fontSize: 24)))
              ],
            ),
          )
        ],
      ),
    );
  }
}