import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:intl/intl.dart';
import 'nik_check.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'partner_page.dart';
import 'dev_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'publik_chat.dart';
import 'tq_to.dart';
import 'anime_home.dart';
import 'musik_page.dart';
import 'nted_song.dart';

class DashboardPage extends StatefulWidget {
  final String userId;
  final String level;
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.userId,
    required this.level,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  late String sessionKey, username, password, role, expiredDate;
  late List<Map<String, dynamic>> listBug, listDoos;
  late List<dynamic> newsList;
  String androidId = "unknown";
  File? _profileImage;
  VideoPlayerController? _menuVideoController;
  int _bottomNavIndex = 0;
  late Widget _selectedPage;
  int onlineUsers = 0, activeConnections = 0;

     final Color bgBlack = const Color(0xFF0D0D0F);
     final Color cardDark = const Color(0xFF1A0A0A);
     final Color cardDeep = const Color(0xFF3D0A0A);
     final Color accentCyan = const Color(0xFF800000);
     final Color accentMagenta = const Color(0xFFB22222);
     final Color accentGold = const Color(0xFFFFD700);
     final Color accentPurple = const Color(0xFF4A1A1A);
     final Color accentGreen = const Color(0xFF006400);
     final Color accentOrange = const Color(0xFFCC5500);
     final Color accentPink = const Color(0xFF8B0000);
     final Color accentBlue = const Color(0xFF2A1A1A);
     final Color accentTeal = const Color(0xFF3D1A1A);
     final Color textWhite = Colors.white;
     final Color textGrey = const Color(0xFFB0B0B0);

  PageController _pageController = PageController();
  int _currentNewsIndex = 0;

  @override
  void initState() {
    super.initState();
    sessionKey  = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    _controller = AnimationController(
      duration: const Duration(milliseconds: 450),
      vsync: this,
    );
    _animation = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _controller.forward();

    _selectedPage = _buildNewsPage();
    _pageController = PageController();
    _loadProfileImage();
    _initMenuVideo();
    _fetchDashboardStats();
  }

  Future<void> _fetchDashboardStats() async {
    try {
      final response = await http.get(
        Uri.parse('http://udanstore-node.hostkita.help:2861/api/dashboard-stats'),
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) {
          setState(() {
            onlineUsers = data['onlineUsers'] ?? 0;
            activeConnections = data['activeConnections'] ?? 0;
          });
        }
      }
    } catch (_) {}
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_$username');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() => _profileImage = File(imagePath));
    }
  }

  void _initMenuVideo() {
    _menuVideoController = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        setState(() {});
        _menuVideoController?.setLooping(true);
        _menuVideoController?.setVolume(0.0);
        _menuVideoController?.play();
      });
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  void _onBottomNavTapped(int index) {
    setState(() {
      _bottomNavIndex = index;
      if (index == 0) {
        _selectedPage = _buildNewsPage();
      } else if (index == 1) {
        _selectedPage = HomePage(
          isGroup: false,
          username: username,
          password: password,
          listBug: listBug,
          role: role,
          expiredDate: expiredDate,
          sessionKey: sessionKey,
        );
      } else if (index == 2) {
        _selectedPage = InfoPage(sessionKey: sessionKey);
      } else if (index == 3) {
        _selectedPage = ToolsPage(
          username: username,
          sessionKey: sessionKey,
          userRole: role,
          listDoos: listDoos,
        );
      }
    });
  }

  void _onSidebarTabSelected(int index) {
    setState(() {
      switch (index) {
        case 1: _selectedPage = SellerPage(keyToken: sessionKey); break;
        case 2: _selectedPage = AdminPage(sessionKey: sessionKey); break;
        case 3: _selectedPage = OwnerPage(sessionKey: sessionKey, username: username); break;
        case 4: _selectedPage = ModeratorPage(sessionKey: sessionKey, username: username); break;
        case 5: _selectedPage = DevPage(sessionKey: sessionKey, username: username); break;
      }
    });
    Navigator.pop(context);
  }

  Widget _buildNewsPage() {
    final now = DateTime.now();
     final formattedTime = DateFormat('HH:mm').format(now);
    return SingleChildScrollView(
      padding: const EdgeInsets.only(bottom: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
            child: Row(children: [
              Expanded(child: _statCard(Icons.people, 'Online', '$onlineUsers', accentCyan)),
              const SizedBox(width: 12),
              Expanded(child: _statCard(Icons.link, 'Connect', '$activeConnections', accentMagenta)),
            ]),
          ),
          Padding(
           padding: const EdgeInsets.symmetric(vertical: 8),
            child: Text('🕌 Waktu Sholat: $formattedTime WIB',
            style: TextStyle(
              color: accentCyan,
              fontSize: 16,
              fontWeight: FontWeight.bold,
              shadows: [Shadow(color: Colors.black, blurRadius: 8)],
              ),
            ),
          ),
          _buildVideoBanner(),
          const SizedBox(height: 20),
          _buildNewsCarousel(),
          const SizedBox(height: 20),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Wrap(
              spacing: 12,
              runSpacing: 12,
              children: [
                _actionButton('Channel', FontAwesomeIcons.telegram, accentCyan,
                    () => _openUrl('https://t.me/vrxajg')),
                _actionButton('Support', Icons.favorite, accentPink,
                    () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TqPage()))),
                _actionButton('Senders', FontAwesomeIcons.whatsapp, accentGreen,
                    () => Navigator.push(context, MaterialPageRoute(builder: (_) => BugSenderPage(sessionKey: sessionKey, username: username, role: role)))),
                _actionButton('Public Chat', Icons.chat, accentGold,
                    () => Navigator.push(context, MaterialPageRoute(builder: (_) => CommunityPage(username: username, role: role)))),
                if (role == 'reseller')
                  _actionButton('Seller', Icons.store, accentOrange, () => _onSidebarTabSelected(1)),
                if (role == 'partner')
                  _actionButton('Partner', Icons.admin_panel_settings, accentPurple, () => _onSidebarTabSelected(2)),
                if (role == 'owner')
                  _actionButton('Owner', Icons.workspace_premium, accentMagenta, () => _onSidebarTabSelected(3)),
                if (role == 'moderator')
                  _actionButton('Mod', Icons.shield, accentBlue, () => _onSidebarTabSelected(4)),
                if (role == 'developer')
                  _actionButton('Dev', Icons.code, accentTeal, () => _onSidebarTabSelected(5)),
                _actionButton('Profile', Icons.person, accentBlue,
                    () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProfilePage(username: username, password: password, role: role, expiredDate: expiredDate, sessionKey: sessionKey)))),
              ],
            ),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _actionButton(String label, IconData icon, Color color, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: (MediaQuery.of(context).size.width - 44) / 2,
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [color.withOpacity(0.15), color.withOpacity(0.05)]),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Row(children: [
          Icon(icon, color: color, size: 22),
          const SizedBox(width: 10),
          Expanded(child: Text(label, style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13))),
          Icon(Icons.arrow_forward_ios, color: color.withOpacity(0.6), size: 14),
        ]),
      ),
    );
  }

  Widget _statCard(IconData icon, String label, String value, Color color) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cardDark,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: color.withOpacity(0.25)),
        boxShadow: [BoxShadow(color: color.withOpacity(0.1), blurRadius: 10)],
      ),
      child: Row(children: [
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(color: color.withOpacity(0.15), borderRadius: BorderRadius.circular(12)),
          child: Icon(icon, color: color, size: 22),
        ),
        const SizedBox(width: 14),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(label, style: TextStyle(color: textGrey, fontSize: 12)),
          const SizedBox(height: 4),
          Text(value, style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18)),
        ])),
      ]),
    );
  }

   Widget _buildVideoBanner() {
  return Container(
    margin: const EdgeInsets.symmetric(horizontal: 16),
    height: 200,
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(20),
      border: Border.all(color: accentPurple.withOpacity(0.4)),
      boxShadow: [BoxShadow(color: accentPurple.withOpacity(0.2), blurRadius: 15)],
    ),
    child: ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: Stack(
        fit: StackFit.expand,
        children: [
          if (_menuVideoController != null && _menuVideoController!.value.isInitialized)
            FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: _menuVideoController!.value.size.width,
                height: _menuVideoController!.value.size.height,
                child: VideoPlayer(_menuVideoController!),
              ),
            )
          else
            Container(color: cardDeep, child: const Center(child: CircularProgressIndicator(color: Colors.white))),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.transparent, bgBlack.withOpacity(0.9)],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),
          Positioned(
            bottom: 16,
            left: 16,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'TrashGlitch - Apps',
                  style: TextStyle(
                    color: accentGold,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 2,
                    shadows: [Shadow(color: Colors.black, blurRadius: 10)],
                  ),
                ),
                const SizedBox(height: 4),
                Text('Dashboard Control', style: TextStyle(color: textGrey, fontSize: 12)),
              ],
            ),
          ),
        ],
      ),
    ),
  );
}

  Widget _buildNewsCarousel() {
    if (newsList.isEmpty) {
      return Container(
        margin: const EdgeInsets.symmetric(horizontal: 16),
        height: 200,
        decoration: BoxDecoration(color: cardDark, borderRadius: BorderRadius.circular(20)),
        child: Center(child: Text('No news', style: TextStyle(color: textGrey))),
      );
    }
    return Column(children: [
      SizedBox(
        height: MediaQuery.of(context).size.height * 0.4,
        child: PageView.builder(
          controller: _pageController,
          itemCount: newsList.length,
          onPageChanged: (i) => setState(() => _currentNewsIndex = i),
          itemBuilder: (_, i) {
            final item = newsList[i];
            return Container(
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: cardDeep,
                border: Border.all(color: accentCyan.withOpacity(0.3)),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: Stack(fit: StackFit.expand, children: [
                  if (item['image'] != null && item['image'].isNotEmpty)
                    NewsMedia(url: item['image']),
                  Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [bgBlack.withOpacity(0.7), Colors.transparent],
                        begin: Alignment.bottomCenter,
                        end: Alignment.topCenter,
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 20,
                    left: 20,
                    right: 20,
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(item['title'] ?? '',
                          style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 6),
                      Text(item['desc'] ?? '', style: TextStyle(color: textGrey, fontSize: 14)),
                    ]),
                  ),
                ]),
              ),
            );
          },
        ),
      ),
      if (newsList.length > 1)
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(
            newsList.length,
            (i) => AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              margin: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
              height: 8,
              width: _currentNewsIndex == i ? 24 : 8,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: _currentNewsIndex == i ? accentCyan : Colors.white24,
              ),
            ),
          ),
        ),
    ]);
  }

  // ─── DRAWER ────────────────────────────────────────────────────────────
  Widget _buildCustomDrawer() {
    return Drawer(
      backgroundColor: cardDark,
      width: MediaQuery.of(context).size.width * 0.8,
      child: Column(children: [
        Container(
          height: 220,
          decoration: const BoxDecoration(
            gradient: LinearGradient(colors: [Color(0xFFBB86FC), Color(0xFFFF007F)]),
          ),
          child: SafeArea(
            child: Center(
              child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                CircleAvatar(
                  radius: 45,
                  backgroundColor: Colors.white24,
                  child: CircleAvatar(
                    radius: 42,
                    backgroundImage: _profileImage != null ? FileImage(_profileImage!) : null,
                    child: _profileImage == null
                        ? const Icon(Icons.person, size: 40, color: Colors.white)
                        : null,
                  ),
                ),
                const SizedBox(height: 12),
                Text(username,
                    style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
                Text(role.toUpperCase(),
                    style: TextStyle(color: accentGold, fontSize: 13, letterSpacing: 1)),
              ]),
            ),
          ),
        ),
        Expanded(
          child: ListView(padding: const EdgeInsets.symmetric(vertical: 12), children: [
            if (role == "reseller")
              _drawerItem(Icons.store, 'Seller Page', accentOrange, () => _onSidebarTabSelected(1)),
            if (role == "partner")
              _drawerItem(Icons.admin_panel_settings, 'Partner', accentPurple, () => _onSidebarTabSelected(2)),
            if (role == "owner")
              _drawerItem(Icons.workspace_premium, 'Owner', accentMagenta, () => _onSidebarTabSelected(3)),
            if (role == "moderator")
              _drawerItem(Icons.shield, 'Moderator', accentBlue, () => _onSidebarTabSelected(4)),
            if (role == "developer")
              _drawerItem(Icons.code, 'Developer', accentTeal, () => _onSidebarTabSelected(5)),
            _drawerItem(Icons.history, 'Riwayat', accentCyan, () {
              Navigator.pop(context);
              Navigator.push(context,
                  MaterialPageRoute(builder: (_) => RiwayatPage(sessionKey: sessionKey, role: role)));
            }),
            _drawerItem(Icons.music_note_rounded, 'Nted Music', accentPink, () {
              Navigator.pop(context);
              Navigator.push(context, MaterialPageRoute(builder: (_) => const MusicSearchPage()));
            }),
            _drawerItem(Icons.music_note_rounded, 'Smoty Play',                 accentCyan, () {
             Navigator.pop(context);
             Navigator.push(context, MaterialPageRoute(builder: (_) => const MusikPage()));
}),
            const Divider(color: Colors.white24),
            _drawerItem(Icons.logout, 'Logout', Colors.redAccent, () async {
              Navigator.pop(context);
              final prefs = await SharedPreferences.getInstance();
              await prefs.clear();
              if (!mounted) return;
              Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (_) => const LoginPage()), (r) => false);
            }),
          ]),
        ),
      ]),
    );
  }

  Widget _drawerItem(IconData icon, String title, Color color, VoidCallback onTap) {
    return ListTile(
      leading: Icon(icon, color: color),
      title: Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w500)),
      trailing: const Icon(Icons.arrow_forward_ios, size: 14, color: Colors.white38),
      onTap: onTap,
    );
  }

  // ─── BUILD ─────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
        title: Row(children: const [
          Icon(FontAwesomeIcons.key, color: Colors.amber, size: 16),
          SizedBox(width: 8),
          Text('0',
              style: TextStyle(
                  color: Colors.white,
                  fontFamily: 'ShareTechMono',
                  fontWeight: FontWeight.bold)),
        ]),
        actions: [
          GestureDetector(
            onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => ProfilePage(
                        username: username,
                        password: password,
                        role: role,
                        expiredDate: expiredDate,
                        sessionKey: sessionKey))),
            child: Row(children: [
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(username,
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                  Row(children: [
                    Text('#${widget.userId}',
                        style: const TextStyle(color: Colors.white54, fontSize: 10)),
                    const SizedBox(width: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                      decoration: BoxDecoration(
                          color: Colors.white12, borderRadius: BorderRadius.circular(4)),
                      child: Text('Lvl. ${widget.level}',
                          style: const TextStyle(color: Colors.white70, fontSize: 9)),
                    ),
                  ]),
                ],
              ),
              const SizedBox(width: 10),
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: accentCyan, width: 2)),
                child: ClipOval(
                  child: _profileImage != null
                      ? Image.file(_profileImage!, fit: BoxFit.cover)
                      : const Icon(Icons.person, color: Colors.white),
                ),
              ),
            ]),
          ),
          const SizedBox(width: 10),
        ],
      ),
      drawer: _buildCustomDrawer(),
      body: FadeTransition(opacity: _animation, child: _selectedPage),
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          color: Color(0xFF111111),
          border: Border(top: BorderSide(color: Colors.white12)),
        ),
        child: BottomNavigationBar(
          backgroundColor: Colors.transparent,
          type: BottomNavigationBarType.fixed,
          selectedItemColor: accentCyan,
          unselectedItemColor: Colors.white38,
          currentIndex: _bottomNavIndex,
          onTap: _onBottomNavTapped,
          selectedLabelStyle: const TextStyle(fontWeight: FontWeight.bold),
          items: [
            BottomNavigationBarItem(
              icon: Icon(Icons.home,
                  color: _bottomNavIndex == 0 ? accentCyan : Colors.white38),
              label: 'Home',
            ),
            BottomNavigationBarItem(
              icon: Icon(FontAwesomeIcons.whatsapp,
                  color: _bottomNavIndex == 1 ? accentGreen : Colors.white38),
              label: 'Bug',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.info,
                  color: _bottomNavIndex == 2 ? accentMagenta : Colors.white38),
              label: 'Info',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.build,
                  color: _bottomNavIndex == 3 ? accentGold : Colors.white38),
              label: 'Tools',
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _controller?.dispose();
    _menuVideoController?.dispose();
    _pageController?.dispose();
    super.dispose();
  }
}

// ─── CLASS VIDEO & NEWS MEDIA (TIDAK DIUBAH) ────────────────────────────
class _VideoPlayerAsset extends StatefulWidget {
  const _VideoPlayerAsset();
  @override __VideoPlayerAssetState createState() => __VideoPlayerAssetState();
}
class __VideoPlayerAssetState extends State<_VideoPlayerAsset> {
  late VideoPlayerController _controller;
  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        _controller.setLooping(true);
        _controller.setVolume(0.0);
        _controller.play();
        setState(() {});
      });
  }
  @override
  Widget build(BuildContext context) {
    if (_controller.value.isInitialized) {
      return FittedBox(
        fit: BoxFit.cover,
        child: SizedBox(
          width: _controller.value.size.width,
          height: _controller.value.size.height,
          child: VideoPlayer(_controller),
        ),
      );
    }
    return const Center(child: CircularProgressIndicator(color: Colors.grey));
  }
  @override void dispose() { _controller.dispose(); super.dispose(); }
}

class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});
  @override State<NewsMedia> createState() => _NewsMediaState();
}
class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _controller;
  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          setState(() {});
          _controller?.setLooping(true);
          _controller?.setVolume(0.0);
          _controller?.play();
        });
    }
  }
  bool _isVideo(String url) =>
      url.endsWith(".mp4") || url.endsWith(".webm") || url.endsWith(".mov") || url.endsWith(".mkv");
  @override void dispose() { _controller?.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_controller != null && _controller!.value.isInitialized) {
        return AspectRatio(aspectRatio: _controller!.value.aspectRatio, child: VideoPlayer(_controller!));
      }
      return const Center(child: CircularProgressIndicator(color: Colors.grey));
    }
    return Image.network(widget.url, fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(color: Colors.grey.shade800, child: const Icon(Icons.error, color: Colors.grey)));
  }
}