import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class IpScannerPage extends StatefulWidget {
  const IpScannerPage({super.key});

  @override
  State<IpScannerPage> createState() => _IpScannerPageState();
}

class _IpScannerPageState extends State<IpScannerPage> {
  final TextEditingController _domainController = TextEditingController();
  bool _isLoading = false;
  String? _result;
  String? _error;

  // Tema hitam-putih-abu
  final Color bgBlack = Colors.black;
  final Color greyDark = Colors.grey[800]!;
  final Color greyLight = Colors.grey[500]!;
  final Color redDark = const Color(0xFFB71C1C);

  Future<void> _scanIp() async {
    final domain = _domainController.text.trim();
    if (domain.isEmpty) {
      setState(() {
        _error = "Masukkan domain/URL";
        _result = null;
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _error = null;
      _result = null;
    });

    try {
      // Gunakan API publik untuk mendapatkan IP
      final url = Uri.parse("https://api.siputzx.my.id/api/tools/dns?domain=$domain");
      final response = await http.get(url);
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == true && data['data'] != null) {
          final records = data['data']['records'];
          String ipAddress = "Tidak ditemukan";
          if (records['a'] != null && records['a']['response']?['answer'] != null) {
            final aRecords = records['a']['response']['answer'] as List;
            if (aRecords.isNotEmpty) {
              ipAddress = aRecords.first['record']['data'] ?? "Tidak ada A record";
            }
          }
          setState(() {
            _result = "Domain: $domain\nIP Address: $ipAddress";
          });
        } else {
          setState(() {
            _error = "Gagal mendapatkan IP untuk domain tersebut";
          });
        }
      } else {
        setState(() {
          _error = "Gagal terhubung ke server";
        });
      }
    } catch (e) {
      setState(() {
        _error = "Error: $e";
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      appBar: AppBar(
        title: const Text("IP Scanner", style: TextStyle(color: Colors.white, fontFamily: 'Orbitron')),
        backgroundColor: bgBlack,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new, color: greyLight),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
              controller: _domainController,
              style: const TextStyle(color: Colors.white),
              decoration: InputDecoration(
                labelText: "Domain/Website",
                hintText: "contoh: google.com",
                labelStyle: TextStyle(color: greyLight),
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: greyLight.withOpacity(0.5)),
                  borderRadius: BorderRadius.circular(12),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: greyLight),
                  borderRadius: BorderRadius.circular(12),
                ),
                filled: true,
                fillColor: greyDark,
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _isLoading ? null : _scanIp,
              style: ElevatedButton.styleFrom(
                backgroundColor: redDark,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: _isLoading
                  ? const CircularProgressIndicator(color: Colors.white)
                  : const Text("SCAN IP", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 20),
            if (_result != null)
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: greyDark,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: greyLight.withOpacity(0.3)),
                ),
                child: SelectableText(_result!, style: const TextStyle(color: Colors.white, fontFamily: 'ShareTechMono')),
              ),
            if (_error != null)
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: redDark.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: redDark),
                ),
                child: Text(_error!, style: TextStyle(color: redDark)),
              ),
          ],
        ),
      ),
    );
  }
}